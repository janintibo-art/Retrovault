'use strict';
/**
 * RVDB — Couche de persistance IndexedDB pour RetroVault.
 *
 * Deux magasins :
 *   - "roms"  : clé = id du jeu, valeur = { blob:File, name, consoleId, size }
 *   - "saves" : clé = id du jeu, valeur = { state, sram, slots, ... } (étape 2)
 *
 * localStorage ne gère pas les binaires et plafonne à ~5 Mo : on stocke donc
 * les ROMs (qui peuvent peser des dizaines/centaines de Mo) ici.
 *
 * Toutes les méthodes renvoient des Promises. En cas d'indisponibilité
 * d'IndexedDB (mode privé sur certains navigateurs), les appels rejettent et
 * l'appelant retombe proprement sur un toast d'erreur.
 */
const RVDB = (() => {
  const DB_NAME = 'retrovault';
  const DB_VERSION = 2;
  const STORE_ROMS = 'roms';
  const STORE_SAVES = 'saves';
  const STORE_BIOS = 'bios';

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window) || !window.indexedDB) {
        reject(new Error('IndexedDB indisponible'));
        return;
      }
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_ROMS)) db.createObjectStore(STORE_ROMS);
        if (!db.objectStoreNames.contains(STORE_SAVES)) db.createObjectStore(STORE_SAVES);
        if (!db.objectStoreNames.contains(STORE_BIOS)) db.createObjectStore(STORE_BIOS);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('Ouverture IndexedDB échouée'));
    });
    return dbPromise;
  }

  function put(store, key, value) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error || new Error('Écriture échouée'));
      tx.onabort = () => reject(tx.error || new Error('Transaction annulée (stockage plein ?)'));
    }));
  }

  function get(store, key) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error || new Error('Lecture échouée'));
    }));
  }

  function del(store, key) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error || new Error('Suppression échouée'));
    }));
  }

  function keys(store) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAllKeys();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error || new Error('Lecture des clés échouée'));
    }));
  }

  function clear(store) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).clear();
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => reject(tx.error || new Error('Effacement échoué'));
    }));
  }

  return {
    // ROMs
    putRom: (id, file, meta = {}) => put(STORE_ROMS, id, { blob: file, name: file.name, ...meta }),
    getRom: (id) => get(STORE_ROMS, id),
    delRom: (id) => del(STORE_ROMS, id),
    romKeys: () => keys(STORE_ROMS),
    clearRoms: () => clear(STORE_ROMS),
    // Saves (utilisé à l'étape 2)
    putSave: (id, data) => put(STORE_SAVES, id, data),
    getSave: (id) => get(STORE_SAVES, id),
    delSave: (id) => del(STORE_SAVES, id),
    saveKeys: () => keys(STORE_SAVES),
    // BIOS (fichiers système requis par certains cores : PS1, Sega CD, Neo Geo…)
    putBios: (name, file) => put(STORE_BIOS, name, { blob: file, name, size: file.size }),
    delBios: (name) => del(STORE_BIOS, name),
    biosKeys: () => keys(STORE_BIOS),
    getAllBios: () => keys(STORE_BIOS).then(ks => Promise.all(ks.map(k => get(STORE_BIOS, k)))),
    // Quota
    estimate: () => (navigator.storage && navigator.storage.estimate)
      ? navigator.storage.estimate()
      : Promise.resolve(null),
  };
})();
