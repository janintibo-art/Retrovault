'use strict';

// ════════════════════════════════════════════════════
// CONSOLES
// ════════════════════════════════════════════════════
const CONSOLES=[
  {id:'nes',      name:'NES',        full:'Nintendo NES',          year:'1983',ico:'🟥',cores:['fceumm','nestopia'],        exts:['nes','zip'],                  rp:'49'},
  {id:'snes',     name:'SNES',       full:'Super Nintendo',        year:'1990',ico:'🟪',cores:['snes9x2010','snes9x2005','snes9x'],exts:['smc','sfc','fig','snes','zip'],rp:'79'},
  {id:'gb',       name:'Game Boy',   full:'Game Boy',              year:'1989',ico:'⬛',cores:['gambatte','tgbdual'],        exts:['gb','zip'],                   rp:'33'},
  {id:'gbc',      name:'GBC',        full:'Game Boy Color',        year:'1998',ico:'🟫',cores:['gambatte','tgbdual'],        exts:['gbc','zip'],                  rp:'43'},
  {id:'gba',      name:'GBA',        full:'Game Boy Advance',      year:'2001',ico:'🔵',cores:['mgba','vba_next'],         exts:['gba','zip'],                  rp:'26'},
  {id:'genesis',  name:'Mega Drive', full:'Sega Mega Drive',       year:'1988',ico:'🔷',cores:['genesis_plus_gx','picodrive'],exts:['md','smd','gen','bin','zip'],rp:'167'},
  {id:'mastersys',name:'Master Sys.',full:'Sega Master System',    year:'1985',ico:'🔶',cores:['genesis_plus_gx'],         exts:['sms','zip'],                  rp:'167'},
  {id:'gamegear', name:'Game Gear',  full:'Sega Game Gear',        year:'1990',ico:'🟠',cores:['genesis_plus_gx'],         exts:['gg','zip'],                   rp:'167'},
  {id:'psx',      name:'PS1',        full:'PlayStation 1',         year:'1994',ico:'🔘',cores:['pcsx_rearmed'],            exts:['iso','bin','cue','pbp','chd','zip'], rp:'27', analog:true, bios:{need:'recommended',file:'scph5501.bin (ou scph5500/5502)'}},
  {id:'pce',      name:'PC Engine',  full:'PC Engine / TG-16',     year:'1987',ico:'🟡',cores:['mednafen_pce_fast'],       exts:['pce','zip'],                  rp:'595'},
  {id:'neogeo',   name:'Neo Geo',    full:'SNK Neo Geo (MVS/AES)', year:'1990',ico:'🔴',cores:['fbalpha2012_neogeo'],      exts:['zip','7z'],                   rp:'80', bios:{need:'required',file:'neogeo.zip'}},
  {id:'neocd',    name:'Neo Geo CD', full:'SNK Neo Geo CD',        year:'1994',ico:'🔴',cores:['neocd'],                  exts:['cue','chd','iso','zip'],       rp:'80', bios:{need:'required',file:'neocd.bin (front/top/cdz)'}},
  {id:'arcade',   name:'Arcade',     full:'Arcade (CPS / FBA)',    year:'——', ico:'🕹️',cores:['fbalpha2012','mame2003_plus','fbalpha2012_cps1','fbalpha2012_cps2'], exts:['zip','7z'], rp:'null', bios:{need:'sometimes',file:'selon la borne (neogeo.zip, etc.)'}},
  {id:'segacd',   name:'Sega CD',    full:'Sega CD / Mega-CD',     year:'1991',ico:'💿',cores:['genesis_plus_gx','picodrive'],exts:['iso','cue','chd','img','zip'], rp:'509', bios:{need:'required',file:'bios_CD_U/E/J.bin'}},
  {id:'lynx',     name:'Lynx',       full:'Atari Lynx',            year:'1989',ico:'🟣',cores:['handy','mednafen_lynx'],  exts:['lnx','zip'],                  rp:'11', bios:{need:'recommended',file:'lynxboot.img'}},
  {id:'ngp',      name:'Neo Geo P.', full:'Neo Geo Pocket (Color)',year:'1998',ico:'🟤',cores:['mednafen_ngp'],           exts:['ngp','ngc','zip'],             rp:'120'},
  {id:'vb',       name:'Virtual Boy',full:'Virtual Boy',           year:'1995',ico:'🔴',cores:['mednafen_vb'],           exts:['vb','vboy','zip'],             rp:'220'},
  {id:'msx',      name:'MSX',        full:'MSX / MSX2',            year:'1983',ico:'🖥️',cores:['bluemsx'],               exts:['rom','mx1','mx2','dsk','zip'], rp:'57'},
  {id:'coleco',   name:'ColecoVision',full:'ColecoVision',         year:'1982',ico:'👾',cores:['gearcoleco'],            exts:['col','cv','zip'],              rp:'null', bios:{need:'required',file:'colecovision.rom'}},
  {id:'c64',      name:'Commodore 64',full:'Commodore 64',         year:'1982',ico:'⌨️',cores:['vice_x64sc','vice_x64'], exts:['d64','t64','prg','crt','tap','g64','zip'], rp:'null'},
  {id:'dos',      name:'PC / DOS',   full:'IBM PC · MS-DOS (DOSBox)',year:'1981',ico:'💾',cores:['dosbox'],            exts:['jsdos','exe','com','bat'],     rp:'null', engine:'jsdos'},
  {id:'wonderswan',name:'WonderSwan',full:'Bandai WonderSwan (C)', year:'1999',ico:'⬜',cores:['mednafen_wswan'],         exts:['ws','wsc','zip'],              rp:'46'},
  // — Émulation non disponible dans la build navigateur (cores non compilés en WASM stable par le buildbot) —
  {id:'n64',      name:'N64',        full:'Nintendo 64',           year:'1996',ico:'🟩',cores:['mupen64plus_next'],         exts:['z64','n64','v64','zip'],       rp:'83', analog:true, unavailable:true},
  {id:'nds',      name:'NDS',        full:'Nintendo DS',           year:'2004',ico:'⚪',cores:['desmume'],                exts:['nds','zip'],                  rp:'77', unavailable:true},
  {id:'atari2600',name:'Atari 2600', full:'Atari 2600',            year:'1977',ico:'🟤',cores:['stella'],                 exts:['a26','bin','zip'],             rp:'3', unavailable:true},
  {id:'atari7800',name:'Atari 7800', full:'Atari 7800',            year:'1986',ico:'🟤',cores:['prosystem'],              exts:['a78','bin','zip'],             rp:'10', unavailable:true},
];
const EXT_MAP={};
CONSOLES.forEach(c=>c.exts.forEach(e=>{if(!EXT_MAP[e])EXT_MAP[e]=c.id;}));

// ════════════════════════════════════════════════════
// ÉTAT
// ════════════════════════════════════════════════════
const G={
  inst:null,running:false,paused:false,
  selCon:'snes',
  lib:[],held:new Set(),
  curId:null,curName:'',autoTimer:null,analogMode:false,ffOn:false,
  keys:{},rebindTarget:null,busyBackup:false,
  rawgKey:localStorage.getItem('rawg_key')||'',
  cfg:{pixelperfect:true,smooth:false,audio:true,haptic:true,fps:false,rewind:false,hidetouchctrl:false,autosave:false,analogstick:false,shader:'',lefty:false,ctrlScale:'md',ctrlOpacity:1,music:true,volume:100},
  libCon:'',hbFilter:'all',hbGames:[],hbLoaded:false,
  // Gamepad
  gpIdx:null,         // index de la manette physique connectée
  gpPrev:{},          // état précédent des boutons (pour détecter press/release)
  gpRAF:null,         // requestAnimationFrame loop
  gpRewinding:false,  // état rewind
  // DOS (js-dos)
  dosRunning:false,dosUrl:null,
  savesCount:0,
};

const BTN_MAP={
  'btn-up':'up','btn-down':'down','btn-left':'left','btn-right':'right',
  'btn-A':'a','btn-B':'b','btn-X':'x','btn-Y':'y',
  'btn-L':'l','btn-R':'r','btn-select':'select','btn-start':'start',
};
// Touches clavier par défaut (bouton → touche). Remappables et persistées (rv_keys).
const DEFAULT_KEYS={
  'btn-up':'ArrowUp','btn-down':'ArrowDown','btn-left':'ArrowLeft','btn-right':'ArrowRight',
  'btn-A':'x','btn-B':'z','btn-X':'s','btn-Y':'a','btn-L':'q','btn-R':'w',
  'btn-start':'Enter','btn-select':' ',
};
// KEYMAP (touche → bouton) reconstruit depuis G.keys ; utilisé par bindKeys.
let KEYMAP={};
function rebuildKeymap(){KEYMAP={};Object.keys(G.keys||{}).forEach(bid=>{const k=G.keys[bid];if(k)KEYMAP[k]=bid;});}

// Mapping Standard Gamepad (W3C) → boutons RetroArch
// https://w3c.github.io/gamepad/#remapping
// Indices pour Xbox One/360, PS4/5, manettes génériques en mode standard
const GP_BUTTON_MAP={
  0:'a',    // A (Xbox) / ✕ (PS)
  1:'b',    // B (Xbox) / ○ (PS)
  2:'x',    // X (Xbox) / □ (PS)
  3:'y',    // Y (Xbox) / △ (PS)
  4:'l',    // LB / L1
  5:'r',    // RB / R1
  // 6 = LT (analogique), 7 = RT (analogique) — gérés séparément
  8:'select',  // View/Back / Share
  9:'start',   // Menu/Start / Options
  12:'up',  // D-pad haut
  13:'down',// D-pad bas
  14:'left',// D-pad gauche
  15:'right',// D-pad droit
};
// Raccourcis manette (combinaisons)
// Menu (9) = sauvegarde, View (8) = charger, LT(6)+RT(7) = pause, LT+LB(4) = rewind
const EXTS_SET=new Set();CONSOLES.forEach(c=>c.exts.forEach(e=>EXTS_SET.add(e)));

// ════════════════════════════════════════════════════
// INIT
// ════════════════════════════════════════════════════
window.addEventListener('load',()=>{
  setTimeout(()=>{document.getElementById('splash').classList.add('gone');setTimeout(()=>document.getElementById('splash').remove(),600);},2000);
  loadPrefs();
  renderConsoleGrid();
  // Le sélecteur de fichiers accepte automatiquement toutes les extensions des consoles
  const inp=document.getElementById('inp-file');if(inp)inp.accept=[...EXTS_SET].map(e=>'.'+e).join(',');
  bindUI();bindKeys();bindResize();bindStick();
  initGamepadAPI();
  initMenuMusic();
  document.addEventListener('fullscreenchange',onFsChange);
  document.addEventListener('webkitfullscreenchange',onFsChange);
  document.addEventListener('visibilitychange',onVisChange);
  window.addEventListener('orientationchange',applyImmersive);
  window.addEventListener('resize',applyImmersive);
  if(screen.orientation&&screen.orientation.addEventListener)screen.orientation.addEventListener('change',applyImmersive);
  updateQuickStats();
  reconcileStorage();
  if(G.rawgKey){document.getElementById('rawg-key').value=G.rawgKey;setApiSt(true);}
});

function loadPrefs(){
  const c=localStorage.getItem('rv_cfg');if(c)try{Object.assign(G.cfg,JSON.parse(c));}catch(e){}
  Object.keys(G.cfg).forEach(k=>{const el=document.getElementById('tog-'+k);if(el)el.classList.toggle('on',G.cfg[k]);});
  const lb=localStorage.getItem('rv_lib');if(lb)try{G.lib=JSON.parse(lb).map(g=>({...g,id:g.id||genId(),file:null,artLoading:false}));}catch(e){}
  G.savesCount=parseInt(localStorage.getItem('rv_saves_count')||'0');
  // Touches clavier personnalisées
  let savedKeys=null;try{savedKeys=JSON.parse(localStorage.getItem('rv_keys')||'null');}catch(e){}
  G.keys={...DEFAULT_KEYS,...(savedKeys||{})};
  rebuildKeymap();
  applyHideTouchCtrl();
  applyFpsCounter();
  applyAnalogStick();
  applyCtrlCustom();
}
function savePrefs(){localStorage.setItem('rv_cfg',JSON.stringify(G.cfg));}
function saveKeys(){localStorage.setItem('rv_keys',JSON.stringify(G.keys));rebuildKeymap();}
function saveLibMeta(){localStorage.setItem('rv_lib',JSON.stringify(G.lib.map(({file,artLoading,...r})=>r)));}

// Identifiant stable unique pour chaque jeu (sert de clé IndexedDB)
function genId(){return 'g_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);}

// Au démarrage : marque les jeux dont la ROM est réellement présente dans IndexedDB.
// Les jeux ajoutés avant cette version (sans blob stocké) seront signalés "à réimporter".
async function reconcileStorage(){
  try{
    const ids=await RVDB.romKeys();
    const set=new Set(ids);
    G.lib.forEach(g=>{g.stored=set.has(g.id);});
    renderLib();
  }catch(e){/* IndexedDB indisponible : on ignore, les fichiers en mémoire restent jouables */}
}

// ════════════════════════════════════════════════════
// WEB GAMEPAD API — manette physique Xbox/PS/Generic
// ════════════════════════════════════════════════════
function initGamepadAPI(){
  // L'événement gamepadconnected est peu fiable sur mobile (il faut presser un bouton,
  // page au premier plan ; manquant si la manette était déjà appairée). On ne s'y fie donc
  // PAS uniquement : on scanne aussi navigator.getGamepads() en continu.
  window.addEventListener('gamepadconnected',e=>{updateGpModal(e.gamepad);detectGamepad();});
  window.addEventListener('gamepaddisconnected',()=>{detectGamepad();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)detectGamepad();});
  window.addEventListener('focus',detectGamepad);
  setInterval(detectGamepad,1000); // filet de sécurité : détecte une manette appairée à tout moment
  detectGamepad();                  // scan initial (manette déjà branchée à l'ouverture)
}

// Cherche la première manette réellement connectée (tous slots confondus)
function findActiveGamepad(){
  const pads=navigator.getGamepads?navigator.getGamepads():[];
  for(let i=0;i<pads.length;i++){if(pads[i]&&pads[i].connected)return{gp:pads[i],index:i};}
  return null;
}

// Gère l'état connecté/déconnecté (indicateur, toast, démarrage du polling)
function detectGamepad(){
  const found=findActiveGamepad();
  if(found){
    if(G.gpIdx===null){
      G.gpIdx=found.index;
      const nm=shortGpName(found.gp.id);
      updateGpIndicator(true,nm);
      toast(`🎮 Manette connectée : ${nm}`);
      updateGpModal(found.gp);
      if(G.cfg.hidetouchctrl)applyHideTouchCtrl();
    }
    // Si un jeu tourne et que la boucle n'est pas active, on la démarre
    if(G.running&&G.inst&&!G.gpRAF)startGpLoop();
  }else if(G.gpIdx!==null){
    G.gpIdx=null;G.gpPrev={};
    updateGpIndicator(false,'No gamepad');
    toast('🎮 Manette déconnectée');
    const c=document.querySelector('.ctrl');if(c)c.classList.remove('gamepad-active');
  }
}

function shortGpName(id){
  if(/xbox|xinput/i.test(id)) return 'Xbox';
  if(/playstation|dualshock|dualsense/i.test(id)) return 'PlayStation';
  if(/nintendo|pro controller/i.test(id)) return 'Nintendo';
  return id.split('(')[0].trim().substring(0,12);
}

function updateGpIndicator(connected,label){
  const el=document.getElementById('gp-indicator');
  el.classList.toggle('off',!connected);
  document.getElementById('gp-label').textContent=label;
  // Réduit la manette tactile si gamepad physique actif
  document.querySelector('.ctrl').classList.toggle('gamepad-active', connected && G.cfg.hidetouchctrl);
}

// Boucle de polling gamepad — requestAnimationFrame 60fps
function startGpLoop(){
  if(G.gpRAF) return;
  let lastFpsTime=performance.now();
  let fpsFrames=0;
  function loop(){
    G.gpRAF=requestAnimationFrame(loop);
    // Compteur FPS (indépendant de la manette)
    if(G.cfg.fps){
      fpsFrames++;
      const now=performance.now();
      if(now-lastFpsTime>=1000){
        const fc=document.getElementById('fps-counter');if(fc)fc.textContent=fpsFrames+' FPS';
        fpsFrames=0; lastFpsTime=now;
      }
    }
    if(!G.running||!G.inst) return;
    // Acquisition de la manette à CHAQUE frame (robuste : index dynamique, détecte
    // une manette activée en cours de partie après un appui bouton)
    const found=findActiveGamepad();
    const gp=found&&found.gp;
    if(!gp) return;
    const prev=G.gpPrev;
    // ── Boutons numériques ──
    gp.buttons.forEach((btn,i)=>{
      const name=GP_BUTTON_MAP[i];
      const pressed=btn.pressed||(btn.value>0.5);
      const wasPressed=!!prev[i];
      if(pressed&&!wasPressed){
        if(name) G.inst.pressDown(name).catch(()=>{});
        prev[i]=true;
        // Highlight bouton tactile correspondant
        highlightTouchBtn(name,true);
      } else if(!pressed&&wasPressed){
        if(name) G.inst.pressUp(name).catch(()=>{});
        prev[i]=false;
        highlightTouchBtn(name,false);
      }
    });
    // ── Axes (sticks analogiques) → D-pad ──
    // Axe 0 = stick gauche X, Axe 1 = stick gauche Y
    const DEAD=0.5;
    const ax0=gp.axes[0]||0, ax1=gp.axes[1]||0;
    handleAxisBtn('left',  ax0<-DEAD, prev, 'axis_left');
    handleAxisBtn('right', ax0>DEAD,  prev, 'axis_right');
    handleAxisBtn('up',    ax1<-DEAD, prev, 'axis_up');
    handleAxisBtn('down',  ax1>DEAD,  prev, 'axis_down');
    // ── Triggers analogiques (LT=axe 6 ou btn[6], RT=axe 7 ou btn[7]) ──
    const lt=(gp.buttons[6]?.value||0)>0.5;
    const rt=(gp.buttons[7]?.value||0)>0.5;
    const lb=gp.buttons[4]?.pressed;
    // LT + RT = Pause
    if(lt&&rt&&!(prev.lt&&prev.rt)){doPause();}
    // LT + LB = Rewind
    if(lt&&lb&&G.cfg.rewind&&!G.gpRewinding){startRewind();}
    else if((!lt||!lb)&&G.gpRewinding){stopRewind();}
    prev.lt=lt; prev.rt=rt;
    // ── Boutons spéciaux (Menu=9=save, View=8=load) ──
    const menuPressed=gp.buttons[9]?.pressed;
    const viewPressed=gp.buttons[8]?.pressed;
    if(menuPressed&&!prev.menu){doSave();}
    if(viewPressed&&!prev.view){doLoad();}
    prev.menu=menuPressed; prev.view=viewPressed;
    G.gpPrev=prev;
  }
  loop();
}

function handleAxisBtn(name,pressed,prev,key){
  if(pressed&&!prev[key]){G.inst?.pressDown(name).catch(()=>{});prev[key]=true;highlightTouchBtn(name,true);}
  else if(!pressed&&prev[key]){G.inst?.pressUp(name).catch(()=>{});prev[key]=false;highlightTouchBtn(name,false);}
}

function highlightTouchBtn(name,on){
  // Retrouve le bouton tactile correspondant
  const idMap={up:'btn-up',down:'btn-down',left:'btn-left',right:'btn-right',
    a:'btn-A',b:'btn-B',x:'btn-X',y:'btn-Y',l:'btn-L',r:'btn-R',select:'btn-select',start:'btn-start'};
  const el=document.getElementById(idMap[name]);
  if(el) el.classList.toggle('pr',on);
}

function stopGpLoop(){
  if(G.gpRAF){cancelAnimationFrame(G.gpRAF);G.gpRAF=null;}
}

let rewindTimer=null;
async function startRewind(){
  if(!G.inst||!G.running||rewindTimer) return;
  G.gpRewinding=true;
  document.getElementById('rewind-ind').classList.add('on');
  const tick=()=>{try{G.inst.sendCommand('REWIND');}catch(e){}};
  tick();
  rewindTimer=setInterval(tick,90); // rembobinage continu tant que maintenu
}
async function stopRewind(){
  G.gpRewinding=false;
  if(rewindTimer){clearInterval(rewindTimer);rewindTimer=null;}
  document.getElementById('rewind-ind').classList.remove('on');
}

// ════════════════════════════════════════════════════
// AVANCE RAPIDE & FILTRES VIDÉO
// ════════════════════════════════════════════════════
function doFastForward(){
  if(!G.inst||!G.running){toast('⚠️ Aucun jeu');return;}
  try{
    G.inst.sendCommand('FAST_FORWARD'); // bascule on/off
    G.ffOn=!G.ffOn;
    const b=document.getElementById('btn-ff');if(b)b.classList.toggle('pr',G.ffOn);
    if(G.cfg.haptic&&navigator.vibrate)navigator.vibrate(10);
    toast(G.ffOn?'⏩ Avance rapide':'▶ Vitesse normale');
  }catch(e){toast('❌ '+(e.message||e));}
}

// Shaders simple-passe vérifiés (chargés depuis libretro/glsl-shaders via jsDelivr)
const SHADERS={
  '':            {name:'Aucun',      ico:'⬜'},
  'zfast-crt':   {name:'CRT rapide', ico:'📺', path:'crt/zfast-crt'},
  'crt-easymode':{name:'CRT',        ico:'📺', path:'crt/crt-easymode'},
  'crt-pi':      {name:'CRT Pi',     ico:'📺', path:'crt/crt-pi'},
  'zfast-lcd':   {name:'LCD',        ico:'🟩', path:'handheld/zfast-lcd'},
};
function renderShaderChips(){
  const box=document.getElementById('shader-chips');if(!box)return;
  box.innerHTML=Object.keys(SHADERS).map(k=>`<div class="sh-chip ${G.cfg.shader===k?'on':''}" onclick="setShader('${k}')">${SHADERS[k].ico} ${SHADERS[k].name}</div>`).join('');
}
function setShader(k){
  if(!(k in SHADERS))return;
  G.cfg.shader=k;savePrefs();renderShaderChips();
  toast(G.running?`✅ ${SHADERS[k].name} — « Appliquer » pour relancer`:`✅ Filtre : ${SHADERS[k].name}`);
}
async function reloadCurrent(){
  if(!G.curId){toast('⚠️ Aucun jeu en cours');return;}
  const g=G.lib.find(x=>x.id===G.curId);
  if(!g){toast('⚠️ Relancez depuis la bibliothèque');return;}
  launchLib(G.lib.indexOf(g));
}

function updateGpModal(gp){
  const t=document.getElementById('gp-modal-title');
  const s=document.getElementById('gp-modal-sub');
  const c=document.getElementById('gp-modal-content');
  t.textContent='🎮 '+shortGpName(gp.id);
  s.textContent=`${gp.buttons.length} boutons · ${gp.axes.length} axes · Mapping: ${gp.mapping||'?'}`;
  c.innerHTML=`
    <div class="gp-map-grid">
      <div class="gp-map-row"><span class="gp-btn-name">A / ✕</span><span class="gp-btn-map">→ A (SNES)</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">B / ○</span><span class="gp-btn-map">→ B (SNES)</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">X / □</span><span class="gp-btn-map">→ X (SNES)</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">Y / △</span><span class="gp-btn-map">→ Y (SNES)</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">LB / L1</span><span class="gp-btn-map">→ L</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">RB / R1</span><span class="gp-btn-map">→ R</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">D-Pad</span><span class="gp-btn-map">→ D-Pad</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">Stick G.</span><span class="gp-btn-map">→ D-Pad</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">View / ⊞</span><span class="gp-btn-map">→ SELECT</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">Menu / ☰</span><span class="gp-btn-map">→ START</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">☰ (seul)</span><span class="gp-btn-map">→ 💾 Sauver</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">⊞ (seul)</span><span class="gp-btn-map">→ 📤 Charger</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">LT + RT</span><span class="gp-btn-map">→ ⏸ Pause</span></div>
      <div class="gp-map-row"><span class="gp-btn-name">LT + LB</span><span class="gp-btn-map">→ ⏪ Rewind</span></div>
    </div>
    <div style="font-size:.68rem;color:#475569;margin-top:8px;line-height:1.5">
      ID: <span style="color:#a855f7">${esc(gp.id)}</span><br>
      Index: ${gp.index} · Boutons: ${gp.buttons.length} · Axes: ${gp.axes.length}
    </div>`;
}

// ════════════════════════════════════════════════════
// NAVIGATION
// ════════════════════════════════════════════════════
const PAGE_BN={'page-emu':'bn-emu','page-lib':'bn-lib','page-hb':'bn-hb','page-cfg':'bn-cfg'};
function navPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.bn-item').forEach(b=>b.classList.remove('on'));
  document.getElementById(id).classList.add('on');
  if(PAGE_BN[id])document.getElementById(PAGE_BN[id]).classList.add('on');
  if(id==='page-lib'){renderLib();renderConFilter();}
  if(id==='page-hb'&&!G.hbLoaded)loadHbCatalog();
  if(id==='page-cfg'){renderBiosList();renderShaderChips();renderKeymap();renderCtrlCustom();}
}

// ════════════════════════════════════════════════════
// CONSOLE GRID
// ════════════════════════════════════════════════════
// Iconographie cohérente : couleur d'accent par console + icône cartouche
// (remplace les emoji-carrés), et pochette de secours dégradé + monogramme.
const CON_COLORS={
  nes:'#e84855', snes:'#8b7fe8', gb:'#7c9a3d', gbc:'#c065c0', gba:'#6c5ce7',
  genesis:'#3b82f6', mastersys:'#ef4444', gamegear:'#64748b', psx:'#9aa0a6',
  pce:'#f97316', neogeo:'#eab308', neocd:'#f59e0b', arcade:'#ec4899',
  segacd:'#2563eb', lynx:'#84cc16', ngp:'#38bdf8', vb:'#dc2626', msx:'#14b8a6',
  coleco:'#a855f7', c64:'#60a5fa', wonderswan:'#f472b6', n64:'#22c55e',
  nds:'#94a3b8', atari2600:'#b4884e', atari7800:'#b4884e', dos:'#cbd5e1'
};
function conColor(id){return CON_COLORS[id]||'#7c3aed';}
function platColor(p){p=(p||'').toUpperCase();
  if(p.includes('NES'))return CON_COLORS.nes;
  if(p.includes('GBA'))return CON_COLORS.gba;
  if(p.includes('GBC')||p.includes('COLOR'))return CON_COLORS.gbc;
  if(p.includes('GB'))return CON_COLORS.gb;
  return'#7c3aed';}
function monogram(t){
  const w=(t||'').replace(/[^A-Za-z0-9 ]/g,' ').trim().split(/\s+/).filter(Boolean);
  if(!w.length)return'★';
  if(w.length===1)return w[0].slice(0,2).toUpperCase();
  return(w[0][0]+w[1][0]).toUpperCase();}
// Cartouche SVG teintée — sans <defs> id, donc aucune collision entre cartes
function cartSvg(color){return `<svg viewBox="0 0 48 48" class="cart-svg" aria-hidden="true">
  <path d="M13 4h18a5 5 0 0 1 5 5v33a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2V9a5 5 0 0 1 5-5z" fill="${color}"/>
  <path d="M13 4h18a5 5 0 0 1 5 5v3H8V9a5 5 0 0 1 5-5z" fill="rgba(255,255,255,.18)"/>
  <rect x="13" y="15" width="22" height="12" rx="2" fill="rgba(255,255,255,.92)"/>
  <rect x="17" y="33" width="14" height="2.2" rx="1.1" fill="rgba(0,0,0,.22)"/>
  <rect x="17" y="37.5" width="14" height="2.2" rx="1.1" fill="rgba(0,0,0,.22)"/></svg>`;}
function hbPlaceholder(title,plat){const col=platColor(plat);
  return `<div class="hb-ph" style="background:linear-gradient(150deg,${col}38,#0a0a14 78%)">
    <span class="hb-ph-mono" style="color:${col}">${monogram(title)}</span>
    <span class="hb-ph-sys">${esc(plat)}</span></div>`;}

function renderConsoleGrid(){
  document.getElementById('console-grid').innerHTML=CONSOLES.map(c=>{
    const badge=c.unavailable?'<div class="con-badge cb-na">indispo</div>'
      :(c.engine==='jsdos'?'<div class="con-badge cb-beta">bêta</div>'
      :(c.bios?'<div class="con-badge cb-bios">🔑</div>':'<div class="con-badge"></div>'));
    return `
    <div class="con-card ${G.selCon===c.id?'sel':''} ${c.unavailable?'unavail':''}" onclick="selectConsole('${c.id}')">
      ${badge}
      <div class="con-ico"><img class="con-ico-img" src="icons/consoles/${c.id}.png?v=8" alt="" loading="lazy"></div>
      <div class="con-name">${c.name}</div>
      <div class="con-year">${c.year}</div>
    </div>`;
  }).join('');
}
function selectConsole(id){
  G.selCon=id;renderConsoleGrid();const c=CONSOLES.find(c=>c.id===id);
  if(c.unavailable){toast(`⚠️ ${c.full} : émulation indisponible dans le navigateur`,3600);return;}
  if(c.engine==='jsdos'){toast('💾 PC / DOS via js-dos (bêta) · chargez un .zip de jeu DOS ou un bundle .jsdos',4600);setTimeout(()=>toast('▶️ Astuce : testez le bouton « Démo DOS » sur l\'accueil',4200),1700);return;}
  toast(`${c.ico} ${c.full}`+(c.bios?` · 🔑 BIOS ${c.bios.need==='required'?'requis':c.bios.need==='recommended'?'conseillé':'parfois requis'}`:''));
}
function detectConsole(fn){
  const ext=fn.split('.').pop().toLowerCase();
  const sel=CONSOLES.find(c=>c.id===G.selCon);
  // .zip → DOS uniquement si la console DOS est sélectionnée (zip est partagé par d'autres systèmes).
  // .jsdos/.exe/.com/.bat sont propres à DOS et déjà résolus par EXT_MAP.
  if(ext==='zip'&&sel&&sel.engine==='jsdos')return 'dos';
  return EXT_MAP[ext]||G.selCon;
}

// ════════════════════════════════════════════════════
// MOTEUR DOS — js-dos (DOSBox WebAssembly) pour les jeux PC
// js-dos est chargé à la demande depuis son CDN ; il a besoin de l'isolation
// cross-origin (déjà active via le service worker) pour SharedArrayBuffer.
// ════════════════════════════════════════════════════
let jsdosLoaded=false,jsdosLoading=null,dosProps=null;
function loadJsDos(){
  if(jsdosLoaded)return Promise.resolve();
  if(jsdosLoading)return jsdosLoading;
  jsdosLoading=new Promise((resolve,reject)=>{
    if(!document.getElementById('jsdos-css')){
      const css=document.createElement('link');css.id='jsdos-css';css.rel='stylesheet';
      css.href='https://v8.js-dos.com/latest/js-dos.css';document.head.appendChild(css);
    }
    const s=document.createElement('script');s.id='jsdos-js';s.src='https://v8.js-dos.com/latest/js-dos.js';
    s.onload=()=>{jsdosLoaded=true;resolve();};
    s.onerror=()=>{jsdosLoading=null;reject(new Error('js-dos introuvable'));};
    document.head.appendChild(s);
  });
  return jsdosLoading;
}

// Choisit l'exécutable le plus probable dans une archive DOS
function pickDosExec(entries,base){
  const exe=entries.filter(p=>/\.(exe|com|bat)$/i.test(p.path));
  if(!exe.length)return null;
  const bad=/(install|setup|config|setsound|setup|uninst|dos4gw|dos32a|cwsdpmi|select|readme|order|help)/i;
  const good=['start','play','run','go','game','launch',base].filter(Boolean);
  const score=p=>{
    const fn=p.path.split('/').pop().toLowerCase();
    const stem=fn.replace(/\.(exe|com|bat)$/i,'');
    let s=0;
    if(/\.bat$/i.test(fn))s+=3; else if(/\.com$/i.test(fn))s+=1;
    if(good.includes(stem))s+=5;
    if(bad.test(stem))s-=5;
    s+=Math.max(0,4-p.path.split('/').length); // favorise la racine
    return s;
  };
  return exe.sort((a,b)=>score(b)-score(a))[0].path;
}

// Emballe un fichier DOS brut (.zip / .exe / .com / .bat) en bundle .jsdos exécutable.
// Un .jsdos (ou un .zip contenant déjà .jsdos/dosbox.conf) est renvoyé tel quel.
async function wrapDosFile(file){
  const lower=file.name.toLowerCase();
  if(lower.endsWith('.jsdos'))return file;
  const JSZip=await loadJSZip();
  const mkConf=(dir,exe)=>'[sdl]\nautolock=false\n[cpu]\ncycles=auto\n[autoexec]\nmount c .\nc:\n'+(dir?('cd '+dir+'\n'):'')+exe+'\n';
  if(lower.endsWith('.zip')){
    const zip=await new JSZip().loadAsync(file);
    if(zip.file('.jsdos/dosbox.conf'))return file; // déjà un bundle valide
    const entries=[];zip.forEach((path,e)=>{if(!e.dir)entries.push({path});});
    const exec=pickDosExec(entries,lower.replace(/\.zip$/,''));
    if(!exec)throw new Error("Aucun exécutable (.exe/.com/.bat) trouvé dans l'archive");
    const dir=exec.split('/').slice(0,-1).join('\\'),exe=exec.split('/').pop();
    zip.file('.jsdos/dosbox.conf',mkConf(dir,exe));
    return await zip.generateAsync({type:'blob'});
  }
  if(/\.(exe|com|bat)$/i.test(lower)){
    const zip=new JSZip();
    zip.file(file.name,file);
    zip.file('.jsdos/dosbox.conf',mkConf('',file.name));
    return await zip.generateAsync({type:'blob'});
  }
  return file;
}

async function launchDos(src,con,gameId){
  // src = File (bundle .jsdos importé) OU chaîne URL (démo hébergée)
  const isUrl=typeof src==='string';
  const name=isUrl?'Démo DOS (Digger)':cleanName(src.name);
  // Stoppe un éventuel jeu RetroArch en cours
  if(G.inst){try{await persistSRAM();}catch(e){}stopAutoLoop();stopGpLoop();stopRewind();try{G.inst.exit();}catch(e){}G.inst=null;G.running=false;G.paused=false;G.held.clear();}
  navPage('page-emu');hideEmuMsg();
  document.getElementById('home-overlay').classList.add('gone');
  document.getElementById('canvas-box').style.display='none';
  document.getElementById('touch-ctrl').style.display='none';
  showLoad('Chargement de DOSBox (js-dos)…',25);
  try{await loadJsDos();}
  catch(e){
    hideLoad();
    document.getElementById('canvas-box').style.display='';
    document.getElementById('touch-ctrl').style.display='';
    showEmuMsg(`<div style="font-size:2rem;margin-bottom:8px">⚠️</div>
      <div style="font-weight:700;margin-bottom:6px">js-dos n'a pas pu se charger</div>
      <div style="font-size:.74rem;color:#94a3b8;max-width:300px;margin:0 auto;line-height:1.6">Vérifie ta connexion : le moteur DOS est téléchargé depuis <code>v8.js-dos.com</code>.</div>
      <button class="btn sec" style="margin-top:14px;max-width:200px" onclick="backToHome()">← Retour</button>`);
    return;
  }
  hideLoad();
  if(typeof window.Dos!=='function'){toast('⚠️ js-dos indisponible');backToHome();return;}
  // Emballe un fichier brut (.zip/.exe) en bundle .jsdos exécutable
  let bundle=src;
  if(!isUrl){
    showLoad('Préparation du jeu DOS…',60);
    try{bundle=await wrapDosFile(src);}
    catch(e){
      hideLoad();
      document.getElementById('canvas-box').style.display='';
      document.getElementById('touch-ctrl').style.display='';
      showEmuMsg(`<div style="font-size:2rem;margin-bottom:8px">💾</div>
        <div style="font-weight:700;margin-bottom:6px">Impossible de préparer ce jeu DOS</div>
        <div style="font-size:.74rem;color:#94a3b8;max-width:320px;margin:0 auto;line-height:1.6">${esc(e.message||String(e))}.<br><br>Astuce : fournissez un <code>.zip</code> contenant le jeu et son <code>.exe</code>/<code>.bat</code>, ou un bundle <code>.jsdos</code> créé sur <code>v8.js-dos.com</code>.</div>
        <button class="btn sec" style="margin-top:14px;max-width:200px" onclick="backToHome()">← Retour</button>`);
      return;
    }
    hideLoad();
  }
  const dz=document.getElementById('dos-container');
  dz.style.display='block';dz.innerHTML='';
  document.getElementById('dos-exit').style.display='block';
  if(G.dosUrl){try{URL.revokeObjectURL(G.dosUrl);}catch(e){}G.dosUrl=null;}
  const bundleUrl=isUrl?src:URL.createObjectURL(bundle);
  if(!isUrl)G.dosUrl=bundleUrl; // seuls les blob: sont à révoquer
  G.dosRunning=true;G.curName=name;
  showMusicBtn(false);updateMusicState();showFsBtn(true);applyImmersive();keepAwake(true);startPlaySession();
  document.getElementById('infostrip').textContent=`💾 ${name}  ·  MS-DOS (DOSBox)  ·  js-dos`;
  try{
    dosProps=window.Dos(dz,{
      url:bundleUrl,
      theme:'dracula',
      renderAspect:'4/3',
      imageRendering:G.cfg.pixelperfect?'pixelated':'smooth',
      backend:'dosbox',backendLocked:true,
      autoStart:true,noCloud:true,
      volume:G.cfg.audio?1:0,
      onEvent:(ev)=>{if(ev==='ci-ready')toast('✅ DOS prêt');}
    });
  }catch(e){toast('⚠️ Erreur js-dos : '+(e.message||e),4000);}
}
function dosDemo(){launchDos('https://v8.js-dos.com/bundles/digger.jsdos',CONSOLES.find(c=>c.id==='dos'));}

function teardownDos(){
  if(!G.dosRunning)return;
  try{if(dosProps&&typeof dosProps.stop==='function')dosProps.stop();}catch(e){}
  dosProps=null;
  if(G.dosUrl){try{URL.revokeObjectURL(G.dosUrl);}catch(e){}G.dosUrl=null;}
  const dz=document.getElementById('dos-container');if(dz){dz.style.display='none';dz.innerHTML='';}
  const ex=document.getElementById('dos-exit');if(ex)ex.style.display='none';
  document.getElementById('canvas-box').style.display='';
  document.getElementById('touch-ctrl').style.display='';
  G.dosRunning=false;
}
function exitDos(){teardownDos();backToHome();}

// Overlay de message (console indisponible, erreur DOS…) — NON destructif :
// il masque l'accueil sans en effacer le contenu (la grille de consoles reste intacte).
function showEmuMsg(html){
  const m=document.getElementById('emu-msg');m.innerHTML=html;m.style.display='flex';
  document.getElementById('home-overlay').classList.add('gone');
}
function hideEmuMsg(){const m=document.getElementById('emu-msg');if(m){m.style.display='none';m.innerHTML='';}}
function backToHome(){
  hideEmuMsg();
  document.getElementById('home-overlay').classList.remove('gone');
  document.getElementById('infostrip').textContent='RetroVault · Sélectionnez une console et chargez une ROM';
  logPlaytime();stopRewind();showMusicBtn(true);updateMusicState();showFsBtn(false);if(inFs())exitFs();document.body.classList.remove('imm');keepAwake(false);
}

// ════════════════════════════════════════════════════
// MUSIQUE DE MENU — deux pistes en boucle, coupables à tout moment
// Démarre uniquement sur le menu (jamais pendant un jeu) et seulement après une
// première interaction utilisateur (politique « autoplay » des navigateurs).
// ════════════════════════════════════════════════════
const MENU_TRACKS=['assets/music-1.mp3','assets/music-2.mp3'];
let menuAudio=null, menuTrackIdx=0, musicArmed=false;
function initMenuMusic(){
  menuAudio=new Audio();
  menuAudio.volume=0.42;
  menuAudio.preload='none';
  menuAudio.addEventListener('ended',()=>{                 // enchaîne l'autre piste
    menuTrackIdx=(menuTrackIdx+1)%MENU_TRACKS.length;
    menuAudio.src=MENU_TRACKS[menuTrackIdx];
    if(G.cfg.music&&!inGame())menuAudio.play().catch(()=>{});
  });
  const arm=()=>{if(musicArmed)return;musicArmed=true;updateMusicState();};
  window.addEventListener('pointerdown',arm);
  window.addEventListener('keydown',arm);
  syncMusicUI();
}
function inGame(){return (G.inst&&G.running)||G.dosRunning;}
function updateMusicState(){
  if(!menuAudio)return;
  if(G.cfg.music&&musicArmed&&!inGame()){
    if(!menuAudio.src)menuAudio.src=MENU_TRACKS[menuTrackIdx];
    if(menuAudio.paused){menuAudio.volume=0;menuAudio.play().catch(()=>{});fadeMusic(0.42);}
  }else{
    menuAudio.pause();
  }
}
function syncMusicUI(){
  const t=document.getElementById('tog-music');if(t)t.classList.toggle('on',!!G.cfg.music);
  const b=document.getElementById('music-btn');if(b){b.textContent=G.cfg.music?'🎵':'🔇';b.classList.toggle('off',!G.cfg.music);}
}
function showMusicBtn(show){const b=document.getElementById('music-btn');if(b)b.style.display=show?'flex':'none';}

// ════════════════════════════════════════════════════
// CONFORT DE JEU : écran allumé + pause auto en arrière-plan
// ════════════════════════════════════════════════════
let wakeLock=null,musFade=null;
async function keepAwake(on){
  try{
    if(on){if('wakeLock' in navigator&&!wakeLock){wakeLock=await navigator.wakeLock.request('screen');wakeLock.addEventListener('release',()=>{wakeLock=null;});}}
    else if(wakeLock){const w=wakeLock;wakeLock=null;await w.release();}
  }catch(e){wakeLock=null;}
}
function fadeMusic(target){
  if(!menuAudio)return;
  if(musFade){clearInterval(musFade);musFade=null;}
  musFade=setInterval(()=>{
    const v=menuAudio.volume;
    if(Math.abs(v-target)<0.035){menuAudio.volume=target;clearInterval(musFade);musFade=null;}
    else menuAudio.volume=Math.min(1,Math.max(0,v+(target>v?0.035:-0.035)));
  },60);
}
function onVisChange(){
  if(document.hidden){
    if(menuAudio&&!menuAudio.paused)menuAudio.pause();
    if(G.running&&G.inst&&!G.paused){G.bgPaused=true;try{G.inst.pause();}catch(e){}}
    keepAwake(false);
  }else{
    if(G.bgPaused){G.bgPaused=false;try{G.inst&&G.inst.resume();}catch(e){}}
    if(gameOn())keepAwake(true);
    updateMusicState();
  }
}

// ════════════════════════════════════════════════════
// NOUVELLES FONCTIONS DE JEU : rewind, turbo, capture, volume
// ════════════════════════════════════════════════════
let rwTimer=null,turboTimer=null,turboPhase=false;
// ⏪ Retour arrière : MAINTENIR le bouton → rembobine tant qu'on appuie
function startRewind(){
  if(!G.inst||!G.running){toast('⚠️ Aucun jeu en cours');return;}
  if(!G.cfg.rewind){toast('⏪ Activez « Rewind » dans Options (léger coût mémoire), puis relancez le jeu',5200);return;}
  if(rwTimer)return;
  const b=document.getElementById('btn-rw');if(b)b.classList.add('pr');
  try{G.inst.sendCommand('REWIND');}catch(e){}
  rwTimer=setInterval(()=>{try{G.inst.sendCommand('REWIND');}catch(e){}},90);
  if(G.cfg.haptic&&navigator.vibrate)navigator.vibrate(8);
}
function stopRewind(){if(rwTimer){clearInterval(rwTimer);rwTimer=null;}const b=document.getElementById('btn-rw');if(b)b.classList.remove('pr');}
// 🔥 Turbo : A et B tirent en rafale tant qu'ils sont maintenus
function toggleTurbo(){
  G.turbo=!G.turbo;
  const b=document.getElementById('btn-turbo');if(b)b.classList.toggle('pr',G.turbo);
  if(G.cfg.haptic&&navigator.vibrate)navigator.vibrate(10);
  toast(G.turbo?'🔥 Turbo A/B activé (rafale)':'🔥 Turbo coupé');
  syncTurbo();
}
function syncTurbo(){
  if(G.turbo&&!turboTimer){
    turboTimer=setInterval(()=>{
      if(!G.inst||!G.running||G.paused)return;
      turboPhase=!turboPhase;
      ['btn-A','btn-B'].forEach(id=>{
        if(G.held.has(id)){const n=BTN_MAP[id];try{turboPhase?G.inst.pressUp(n):G.inst.pressDown(n);}catch(e){}}
      });
    },70);
  }else if(!G.turbo&&turboTimer){
    clearInterval(turboTimer);turboTimer=null;
    ['btn-A','btn-B'].forEach(id=>{if(G.held.has(id)){const n=BTN_MAP[id];try{G.inst&&G.inst.pressDown(n);}catch(e){}}});
  }
}
// 📸 Capture d'écran : partage (galerie) si possible, sinon téléchargement
async function takeShot(){
  if(!G.inst||!G.running){toast('⚠️ Aucun jeu en cours');return;}
  try{
    let blob=null;
    if(typeof G.inst.screenshot==='function'){try{blob=await G.inst.screenshot();}catch(e){}}
    if(!blob){const cv=document.getElementById('emu-canvas');if(cv&&cv.toBlob)blob=await new Promise(r=>cv.toBlob(r,'image/png'));}
    if(!blob||!blob.size)throw new Error('capture indisponible sur ce jeu');
    const name=(G.curName||'retrovault').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'-')+'-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'')+'.png';
    const file=new File([blob],name,{type:'image/png'});
    if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file]}).catch(()=>{});}
    else{const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);}
    toast('📸 Capture du jeu enregistrée');
  }catch(e){toast('❌ Capture : '+(e.message||e));}
}
// 🔊 Volume des jeux (pourcentage → décibels RetroArch)
function volDb(p){p=Math.max(0,Math.min(100,p==null?100:+p));if(p<=0)return -80;return Math.round(20*Math.log10(p/100)*10)/10;}
function setGameVol(v){
  G.cfg.volume=Math.max(0,Math.min(100,parseInt(v,10)||0));savePrefs();
  const l=document.getElementById('game-vol-lab');if(l)l.textContent=G.cfg.volume+'%';
  if(G.running)toast('🔊 Appliqué au prochain lancement');
}
// 🖼 Image personnalisée (choisie dans la galerie, réduite puis mémorisée)
function pickArt(){const i=document.getElementById('inp-art');if(i){i.value='';i.click();}}
async function onArtPicked(f){
  const g=G.lib[gameOptIdx];if(!g||!f)return;
  try{
    const url=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(new Error('lecture'));r.readAsDataURL(f);});
    const img=await new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=()=>rej(new Error('image'));im.src=url;});
    const M=256,sc=Math.min(1,M/Math.max(img.width,img.height));
    const cv=document.createElement('canvas');cv.width=Math.max(1,Math.round(img.width*sc));cv.height=Math.max(1,Math.round(img.height*sc));
    cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height);
    g.artwork=cv.toDataURL('image/jpeg',0.78);
    saveLibMeta();renderLib();renderContinue();closeMo(null,'mo-game');toast('🖼 Image appliquée');
  }catch(e){toast('❌ Image illisible');}
}
// ⏱ Temps de jeu + carte « Continuer »
function fmtPlay(s){if(!s||s<60)return null;const m=Math.round(s/60);if(m<60)return m+' min';const h=Math.floor(m/60);return h+' h '+String(m%60).padStart(2,'0');}
function startPlaySession(){
  G.sessStart=Date.now();
  const g=G.lib.find(x=>x.id===G.curId);
  if(g){g.lastPlayed=Date.now();saveLibMeta();}
  renderContinue();
}
function logPlaytime(){
  if(!G.sessStart)return;
  const s=Math.floor((Date.now()-G.sessStart)/1000);G.sessStart=null;
  if(s<5)return;
  const g=G.lib.find(x=>x.id===G.curId);
  if(g){g.playSecs=(g.playSecs||0)+s;g.lastPlayed=Date.now();saveLibMeta();}
  renderContinue();
}
function renderContinue(){
  const w=document.getElementById('continue-wrap');if(!w)return;
  const cands=G.lib.filter(g=>g.lastPlayed&&(g.file||g.stored||g.nativePath));
  if(!cands.length){w.innerHTML='';w.style.display='none';return;}
  const g=cands.sort((a,b)=>b.lastPlayed-a.lastPlayed)[0];
  const i=G.lib.indexOf(g);
  const con=CONSOLES.find(c=>c.id===g.consoleId);
  const pt=fmtPlay(g.playSecs);
  w.style.display='';
  w.innerHTML=`<div class="cont-card" onclick="launchLib(${i})">
    <div class="cont-thumb">${g.artwork?`<img src="${esc(g.artwork)}" onerror="this.remove()">`:`<span>${con?.ico||'🎮'}</span>`}</div>
    <div class="cont-info"><div class="cont-lbl">▶ CONTINUER</div><div class="cont-name">${esc(g.name)}</div><div class="cont-sub">${con?con.name:''}${pt?' · ⏱ '+pt:''}</div></div>
    <div class="cont-go">▶</div>
  </div>`;
}

// ════════════════════════════════════════════════════
// PLEIN ÉCRAN PAYSAGE
// ════════════════════════════════════════════════════
function inFs(){return !!(document.fullscreenElement||document.webkitFullscreenElement);}
function showFsBtn(show){const b=document.getElementById('fs-btn');if(b)b.style.display=show?'flex':'none';}
function enterFs(){
  const el=document.getElementById('page-emu');
  const req=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen;
  if(!req){toast('⚠️ Le plein écran n\'est pas supporté par ce navigateur');return;}
  Promise.resolve(req.call(el)).then(()=>{
    if(screen.orientation&&screen.orientation.lock) screen.orientation.lock('landscape').catch(()=>{});
  }).catch(()=>{});
}
function exitFs(){
  const ex=document.exitFullscreen||document.webkitExitFullscreen;
  try{if(screen.orientation&&screen.orientation.unlock)screen.orientation.unlock();}catch(e){}
  if(ex)Promise.resolve(ex.call(document)).catch(()=>{});
}
function toggleFs(){inFs()?exitFs():enterFs();}
// Redimensionnement robuste du rendu : on le refait plusieurs fois après une
// bascule plein écran/rotation, car les dimensions ne sont correctes qu'une fois
// la nouvelle orientation appliquée par le navigateur.
function resizeEmu(){
  if(!(G.inst&&G.running))return;
  const z=document.getElementById('screen-zone');
  const w=Math.round(z.clientWidth),h=Math.round(z.clientHeight);
  if(w>1&&h>1)G.inst.resize({width:w,height:h}).catch(()=>{});
}
function resizeEmuSoon(){[60,250,500,900].forEach(d=>setTimeout(resizeEmu,d));}
function isLandscape(){return window.innerWidth>window.innerHeight;}
function gameOn(){return !!(G.running||G.dosRunning);}
// Mode immersif : actif dès qu'on est en paysage pendant une partie (avec ou sans
// vrai plein écran navigateur). Masque les barres → le jeu remplit l'écran, manette en surimpression.
function applyImmersive(){
  document.body.classList.toggle('imm', isLandscape()&&gameOn());
  const b=document.getElementById('fs-btn');if(b)b.textContent=inFs()?'✕':'⛶';
  resizeEmuSoon();
}
function onFsChange(){applyImmersive();}

// ════════════════════════════════════════════════════
// CHARGER ROM
// ════════════════════════════════════════════════════
async function loadROM(file,consoleId,gameId){
  if(!file)return;
  teardownDos(); // stoppe DOS si un jeu PC tournait
  const cid=consoleId||detectConsole(file.name);
  const con=CONSOLES.find(c=>c.id===cid)||CONSOLES[1];
  // Moteur DOS (js-dos) au lieu de RetroArch/Nostalgist
  if(con.engine==='jsdos'){await launchDos(file,con,gameId);return;}
  // Console non émulable dans le navigateur : message clair plutôt qu'une erreur cryptique
  if(con.unavailable){
    navPage('page-emu');
    showEmuMsg(`<div style="font-size:2rem;margin-bottom:8px">🚫</div>
      <div style="font-weight:700;margin-bottom:6px">${con.full} non disponible</div>
      <div style="font-size:.74rem;color:#94a3b8;line-height:1.6;max-width:300px;margin:0 auto">
        L'émulateur de ce système (<code>${con.cores[0]}</code>) n'est pas compilé en WebAssembly dans la build standard de RetroArch, il ne peut donc pas tourner dans le navigateur.<br><br>
        Les autres consoles de la bibliothèque fonctionnent normalement.
      </div>
      <button class="btn sec" style="margin-top:14px;max-width:200px" onclick="backToHome()">← Retour</button>`);
    return;
  }
  // Avertissement BIOS si un BIOS est requis et qu'aucun n'a été ajouté
  if(con.bios&&con.bios.need==='required'){
    try{const bk=await RVDB.biosKeys();if(!bk||!bk.length)toast(`🔑 ${con.full} nécessite un BIOS (${con.bios.file}). Ajoutez-le dans Réglages → BIOS.`,5000);}catch(e){}
  }
  // Core : choix par jeu si défini et disponible pour cette console, sinon core par défaut
  const game=gameId?G.lib.find(x=>x.id===gameId):null;
  const core=(game&&game.core&&con.cores.includes(game.core))?game.core:con.cores[0];
  navPage('page-emu');
  showLoad(`${con.ico} ${con.full}…`,5);
  // Avant de quitter le jeu précédent : on persiste sa SRAM et on stoppe l'auto-save
  if(G.inst){await persistSRAM();stopAutoLoop();stopRewind();try{G.inst.exit();}catch(e){}G.inst=null;G.running=false;G.paused=false;G.held.clear();}
  // Récupère la SRAM (sauvegarde interne) déjà stockée pour ce jeu
  let sramBlob=null;
  if(gameId){try{const r=await RVDB.getSave(SRAM_KEY(gameId));sramBlob=r&&r.blob?r.blob:null;}catch(e){}}
  // Rassemble les BIOS stockés (écrits dans le dossier system du core)
  let biosFiles=[];
  try{const all=await RVDB.getAllBios();biosFiles=(all||[]).filter(b=>b&&b.blob).map(b=>new File([b.blob],b.name));}catch(e){}
  // Mode stick : true analogique pour les consoles qui en ont besoin (N64, PS1)
  G.analogMode=!!con.analog;
  G.ffOn=false;const ffb=document.getElementById('btn-ff');if(ffb)ffb.classList.remove('pr');G.turbo=false;syncTurbo();const tb=document.getElementById('btn-turbo');if(tb)tb.classList.remove('pr');
  const shaderPath=(G.cfg.shader&&SHADERS[G.cfg.shader])?SHADERS[G.cfg.shader].path:'';
  try{
    showLoad(`Core ${core}…`,35);
    const{width,height}=getSize();
    const canvas=document.getElementById('emu-canvas');
    showLoad('WASM…',60);
    const opts={
      core,rom:{fileName:file.name,fileContent:file},element:canvas,
      ...(sramBlob?{sram:sramBlob}:{}),
      ...(biosFiles.length?{bios:biosFiles}:{}),
      size:{width,height},
      style:{width:'100%',height:'100%',objectFit:'contain',display:'block',background:'#000',
             imageRendering:G.cfg.pixelperfect?'pixelated':'auto'},
      retroarchConfig:{
        video_scale_integer:'false',
        aspect_ratio_index:'0',video_fullscreen:'true',
        video_smooth:(!G.cfg.pixelperfect&&G.cfg.smooth)?'true':'false',
        rewind_enable:G.cfg.rewind?'true':'false',
        rewind_granularity:'4',
        savestate_thumbnail_enable:'true',
        audio_enable:G.cfg.audio?'true':'false',
        audio_latency:'96',audio_sync:'true',audio_rate_control:'true',audio_volume:String(volDb(G.cfg.volume)),
        // Stick analogique gauche du joueur 1 mappé sur des touches (piloté par le thumbstick tactile)
        input_player1_l_x_minus:'j',input_player1_l_x_plus:'l',
        input_player1_l_y_minus:'i',input_player1_l_y_plus:'k',
      },
    };
    // Lancement, avec repli si le shader échoue à charger (pas d'écran noir)
    for(let w=0;w<40&&!window.Nostalgist;w++)await sleep(200); // attend le moteur (repli éventuel en cours)
    if(!window.Nostalgist)throw new Error('Moteur d\'émulation non chargé — vérifiez la connexion puis réessayez');
    try{
      G.inst=await Nostalgist.launch(shaderPath?{...opts,shader:shaderPath}:opts);
    }catch(shErr){
      if(shaderPath){G.inst=await Nostalgist.launch(opts);setTimeout(()=>toast('⚠️ Filtre vidéo non chargé — lancé sans shader',3500),900);}
      else throw shErr;
    }
    showLoad('Démarrage…',90);await sleep(180);
    hideLoad();
    document.getElementById('home-overlay').classList.add('gone');
    document.getElementById('infostrip').textContent=`${con.ico} ${cleanName(file.name)}  ·  ${con.full}  ·  ${core}  ·  ${G.cfg.pixelperfect?'Pixel-Perfect':'Smooth'}`;
    document.getElementById('btn-pause').textContent='⏸';
    G.running=true;G.paused=false;
    showMusicBtn(false);updateMusicState();showFsBtn(true);applyImmersive();keepAwake(true);startPlaySession();
    G.curId=gameId||null;G.curName=cleanName(file.name);
    // Reprise automatique (si activée) depuis le slot auto
    if(G.cfg.autosave&&gameId){
      try{const ar=await RVDB.getSave(SLOT_KEY(gameId,'auto'));if(ar&&ar.state){await G.inst.loadState(ar.state);toast('↩️ Reprise auto');}}catch(e){}
    }
    startAutoLoop();
    // Démarre le polling manette à chaque lancement : ainsi, presser un bouton en jeu
    // active la détection même si la manette n'avait pas encore été repérée (cas mobile)
    stopGpLoop();startGpLoop();
    // FPS counter
    applyFpsCounter();
    toast(`✅ ${cleanName(file.name)}`);
    if(con.analog&&!G.cfg.analogstick)setTimeout(()=>toast('🕹 Astuce : activez le « Stick analogique » dans les réglages pour cette console',4200),1400);
  }catch(err){
    hideLoad();G.running=false;
    const m=err.message||String(err);
    const isNet=m.includes('SharedArrayBuffer')||m.includes('CORS')||m.includes('cross-origin')||m.includes('blocked');
    const h=document.getElementById('home-overlay');h.classList.remove('gone');
    h.innerHTML=`<div style="font-size:2rem;margin-bottom:8px">⚠️</div>
      <div style="font-family:monospace;font-size:.82rem;font-weight:700;color:#f87171;margin-bottom:8px">${isNet?'Serveur HTTP requis':'Erreur'}</div>
      <div style="font-size:.68rem;color:#475569;white-space:pre-line;max-width:280px;text-align:left;margin-bottom:12px">${isNet?'Ouvrez via HTTP (pas file://).\n• VSCode → Live Server\n• python3 -m http.server\n• Netlify Drop':m.substring(0,200)}</div>
      <button class="home-btn" onclick="resetHome()">← Retour</button>`;
  }
}
function resetHome(){
  const h=document.getElementById('home-overlay');h.classList.remove('gone');
  h.innerHTML=`<div class="home-hero"><div class="home-logo">RetroVault</div><div class="home-sub">22 systèmes · RetroArch + DOSBox</div></div>
    <div class="quick-stats"><div class="qs-item"><div class="qs-num" id="qs-games">0</div><div class="qs-lbl">Jeux</div></div><div class="qs-item"><div class="qs-num" id="qs-hb">0</div><div class="qs-lbl">Homebrew</div></div><div class="qs-item"><div class="qs-num" id="qs-saves">0</div><div class="qs-lbl">Saves</div></div></div>
    <div class="console-grid" id="console-grid"></div>
    <div class="home-actions">
      <button class="home-btn" id="btn-home-pick">📂 Charger ROM</button>
      <button class="home-btn sec" onclick="navPage('page-lib')">📚 Bibliothèque</button>
      <button class="home-btn green" onclick="navPage('page-hb')">🆓 Homebrew</button>
      <button class="home-btn sec" onclick="dosDemo()">💾 Démo DOS</button>
    </div>`;
  renderConsoleGrid();updateQuickStats();
  document.getElementById('btn-home-pick').addEventListener('click',pickROM);
}

// ════════════════════════════════════════════════════
// HOMEBREW HUB
// ════════════════════════════════════════════════════
async function loadHbCatalog(){
  G.hbLoaded=true;
  const grid=document.getElementById('hb-grid');
  grid.innerHTML=`<div class="hb-loading"><div class="mini-spin" style="width:26px;height:26px;border-width:3px"></div><span>Chargement du catalogue…</span></div>`;
  try{
    const res=await fetch('https://hh.gbdev.io/api/all',{signal:AbortSignal.timeout(10000)});
    if(res.ok){const data=await res.json();G.hbGames=Array.isArray(data)?data:(data.content||data.results||[]);renderHbGrid();return;}
  }catch(e){}
  G.hbGames=FALLBACK_HB;renderHbGrid();
}
function setHbFilter(f,el){G.hbFilter=f;document.querySelectorAll('.hb-sf-chip').forEach(c=>c.classList.remove('on'));el.classList.add('on');renderHbGrid();}
function renderHbGrid(){
  const grid=document.getElementById('hb-grid');
  let items=G.hbGames;
  if(G.hbFilter!=='all') items=items.filter(g=>(g.platform||g.system||'').toLowerCase().includes(G.hbFilter));
  if(!items.length){grid.innerHTML=`<div class="hb-loading"><span>Aucun jeu pour ce filtre</span></div>`;return;}
  grid.innerHTML=items.slice(0,80).map((g,i)=>{
    const title=g.title||g.name||'?';
    const dev=g.developer||g.author||'';
    const plat=(g.platform||g.system||'GB').toUpperCase();
    const screens=g.screenshots||[];
    const thumb=screens.length?`https://hh.gbdev.io${screens[0]}`:null;
    return `<div class="hb-card" onclick="openHbDetail(${i})">
      <div class="hb-card-thumb">
        ${hbPlaceholder(title,plat)}${thumb?`<img src="${esc(thumb)}" loading="lazy" onerror="this.remove()">`:''}
        <div class="hb-card-ov"></div><div class="hb-free">FREE</div><div class="hb-card-dl">⬇</div>
      </div>
      <div class="hb-card-info">
        <div class="hb-card-name">${esc(title)}</div>
        <div class="hb-card-meta"><span class="hb-card-sys">${plat}</span><span class="hb-card-auth">${esc(typeof dev==='string'?dev:dev[0]||'')}</span></div>
      </div>
    </div>`;
  }).join('');
}
function platformIco(p){if(p.includes('NES'))return'🟥';if(p.includes('GBA'))return'🔵';if(p.includes('GBC')||p.includes('COLOR'))return'🟫';if(p.includes('GB'))return'⬛';return'🎮';}

function openHbDetail(i){
  const g=G.hbGames[i];if(!g)return;
  const title=g.title||g.name||'?';
  const dev=g.developer||g.author||'';
  const plat=(g.platform||g.system||'GB').toUpperCase();
  const desc=g.description||g.summary||'Jeu homebrew gratuit et légal.';
  const screens=g.screenshots||[];
  const thumb=screens.length?`https://hh.gbdev.io${screens[0]}`:null;
  const urls=g.urls||{};
  const dlUrl=urls.download||urls.rom||g.url||null;
  const hhUrl=g.slug?`https://hh.gbdev.io/game/${g.slug}`:null;
  document.getElementById('mo-hb-sheet').innerHTML=`
    <div class="mh"></div>
    <div class="gd-thumb">${hbPlaceholder(title,plat)}${thumb?`<img src="${esc(thumb)}" onerror="this.remove()">`:''}</div>
    <div class="mt">${esc(title)}</div>
    <div class="dtags"><span class="dtag green">${plat}</span><span class="dtag green">GRATUIT</span><span class="dtag green">LÉGAL</span>${dev?`<span class="dtag">${esc(typeof dev==='string'?dev:dev[0]||'')}</span>`:''}</div>
    <div class="ddesc">${esc(desc)}</div>
    ${dlUrl?`<button class="btn green" id="hb-dl-btn">⬇ Télécharger & Ajouter à la biblio</button>`:''}
    ${hhUrl?`<a href="${esc(hhUrl)}" target="_blank" rel="noopener"><button class="btn sec" style="margin-top:5px">🌐 Voir sur Homebrew Hub</button></a>`:''}
    <button class="btn sec" onclick="closeMo(null,'mo-hb')">Fermer</button>`;
  openMo('mo-hb');
  // Liaison sans interpolation dans le HTML (les titres avec apostrophe ne cassent plus rien)
  if(dlUrl){const b=document.getElementById('hb-dl-btn');if(b)b.addEventListener('click',()=>downloadHb(dlUrl,title,plat.toLowerCase()));}
}

async function downloadHb(url,title,platform){
  toast(`⬇ Téléchargement de ${title}…`);
  try{
    const res=await fetch(url,{signal:AbortSignal.timeout(30000)});
    if(!res.ok)throw new Error('HTTP '+res.status);
    const blob=await res.blob();
    const fname=title.replace(/[^a-zA-Z0-9 ]/g,'').replace(/\s+/g,'_')+'.'+getExtFor(platform);
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=fname;a.click();URL.revokeObjectURL(a.href);
    const file=new File([blob],fname,{type:blob.type});
    const cid=detectConsole(fname);
    if(!G.lib.find(g=>g.name===title)){
      const id=genId();
      G.lib.push({id,file,name:title,size:blob.size,consoleId:cid,artwork:null,fav:false,artLoading:false,homebrew:true,stored:true});
      RVDB.putRom(id,file).catch(e=>toast('⚠️ Stockage : '+(e.message||e)));
      saveLibMeta();updateQuickStats();
    }
    closeMo(null,'mo-hb');
    toast(`✅ ${title} dans la bibliothèque !`);
  }catch(err){toast(`❌ ${err.message}`);}
}
function getExtFor(p){if(p.includes('gba'))return'gba';if(p.includes('gbc')||p.includes('color'))return'gbc';if(p.includes('gb'))return'gb';if(p.includes('nes'))return'nes';return'gb';}

const FALLBACK_HB=[
  {title:'Tobu Tobu Girl',developer:'Tangram Games',platform:'GB',screenshots:[],urls:{download:'https://tangramgames.dk/tobutobugirl/tobutobugirl.gb'},description:'Jeu de plateforme magnifique pour Game Boy. Parmi les meilleurs homebrew existants.'},
  {title:'µCity',developer:'AntonioND',platform:'GBC',screenshots:[],urls:{download:'https://github.com/AntonioND/ucity/releases/download/v1.2/ucity.gbc'},description:'Simulation de ville complète pour Game Boy Color. Construisez votre métropole.'},
  {title:'Böbl',developer:'BennVenn',platform:'NES',screenshots:[],urls:{download:'https://bennyv.itch.io/bbl/purchase'},description:'Platformer NES avec une physique de saut unique et des niveaux exigeants.'},
  {title:'Spacegulls',developer:'Morphcat Games',platform:'NES',screenshots:[],urls:{download:'https://morphcat.itch.io/spacegulls'},description:'Charmant platformer NES avec des oiseaux dans l\'espace.'},
  {title:'Anguna GBA',developer:'',platform:'GBA',screenshots:[],urls:{download:'https://github.com/benfrantzdale/gba-anguna/releases'},description:'Action-RPG complet pour GBA inspiré des classiques Zelda.'},
  {title:'Libbet',developer:'Damian Yerrick',platform:'GB',screenshots:[],urls:{download:'https://pinobatch.itch.io/libbet/purchase'},description:'Puzzle game pour Game Boy avec une mécanique de déplacement originale.'},
];

// ════════════════════════════════════════════════════
// BIBLIOTHÈQUE
// ════════════════════════════════════════════════════
// Ajoute un fichier ; renvoie l'entrée ajoutée/rattachée (ou null). Sans rafraîchissement UI (groupé par l'appelant).
function addOneFile(f){
  const ext=f.name.split('.').pop().toLowerCase();
  if(!EXTS_SET.has(ext))return null;
  const name=cleanName(f.name);
  const existing=G.lib.find(g=>g.name===name);
  if(existing){
    // entrée déjà présente : si elle n'a pas de fichier (ex. restaurée d'une sauvegarde
    // sans les ROMs), on rattache le fichier en réutilisant son id → les sauvegardes se reconnectent
    if(!existing.file){existing.file=f;existing.stored=true;RVDB.putRom(existing.id,f).catch(e=>toast('⚠️ Stockage : '+(e.message||e)));return existing;}
    return null;
  }
  const entry={id:genId(),file:f,name,raw:f.name.replace(/\.[^.]+$/,''),size:f.size,consoleId:detectConsole(f.name),artwork:null,fav:false,artLoading:false,stored:true};
  G.lib.push(entry);
  RVDB.putRom(entry.id,f).catch(e=>toast('⚠️ Stockage : '+(e.message||e)));
  return entry;
}
function addFiles(files){
  const arr=Array.from(files);
  const added=[];
  arr.forEach(f=>{const e=addOneFile(f);if(e)added.push(e);});
  saveLibMeta();renderConFilter();updateQuickStats();renderLib();
  if(!added.length){
    toast('⚠️ Aucun fichier reconnu. Formats acceptés : .nes .smc .sfc .gb .gbc .gba .md .iso .bin .cue .sms .gg .pce .zip…',5200);
    return;
  }
  toast(`✅ ${added.length} ROM(s) ajoutée(s) à la bibliothèque`);
  autoArt(added); // récupère les jaquettes automatiquement, en arrière-plan
  if(arr.length===1){const g0=G.lib.find(x=>x.file===arr[0]);loadROM(arr[0],g0&&g0.consoleId,g0&&g0.id);}
  else navPage('page-lib');
}
// Import d'un ZIP de ROMs : parcourt TOUTES les entrées (sous-dossiers inclus),
// garde les fichiers dont l'extension est reconnue, et les ajoute à la bibliothèque.
async function importZipOfRoms(file){
  if(!file)return;
  toast('📦 Lecture du ZIP…',60000);
  try{
    const JSZip=await loadJSZip();
    const zip=await new JSZip().loadAsync(file);
    const roms=Object.values(zip.files).filter(e=>!e.dir&&EXTS_SET.has((e.name.split('.').pop()||'').toLowerCase()));
    if(!roms.length){toast('⚠️ Aucune ROM reconnue dans ce ZIP (sous-dossiers inclus).',5600);return;}
    const added=[];
    for(let i=0;i<roms.length;i++){
      const blob=await roms[i].async('blob');
      const base=roms[i].name.split('/').pop();
      const e=addOneFile(new File([blob],base,{type:'application/octet-stream'}));
      if(e)added.push(e);
      if(i%8===0||i===roms.length-1)toast(`📦 Extraction ${i+1}/${roms.length}…`,60000);
    }
    saveLibMeta();renderConFilter();updateQuickStats();renderLib();navPage('page-lib');
    toast(`✅ ${added.length} ROM(s) importée(s) depuis le ZIP`,4600);
    autoArt(added); // jaquettes automatiques
  }catch(err){
    toast('⚠️ ZIP illisible : '+(err.message||err),5600);
  }
}
// ════════════════════════════════════════════════════
// SCAN NATIF DU STOCKAGE (APK Capacitor — impossible dans le navigateur)
// ════════════════════════════════════════════════════
// Dans l'APK installé, on a accès au stockage : on parcourt les dossiers, on repère
// les ROMs et on garde leur CHEMIN (sans charger le fichier) → mémoire ménagée.
// Le fichier n'est lu qu'au lancement (launchLib), un seul à la fois.
function isNative(){return !!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform());}
function capFS(){return (window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.Filesystem)||null;}
function b64ToBlob(b64){const bin=atob(b64);const n=bin.length;const a=new Uint8Array(n);for(let i=0;i<n;i++)a[i]=bin.charCodeAt(i);return new Blob([a]);}
function addScannedRom(rawName,size,dir,path){
  const ext=(rawName.split('.').pop()||'').toLowerCase();
  if(!EXTS_SET.has(ext))return null;
  const name=cleanName(rawName);
  if(G.lib.some(g=>g.name===name))return null; // déjà présent (dédoublonnage par nom)
  const entry={id:genId(),file:null,name,raw:rawName.replace(/\.[^.]+$/,''),size:size||0,consoleId:detectConsole(rawName),artwork:null,fav:false,artLoading:false,stored:false,nativeDir:dir,nativePath:path};
  G.lib.push(entry);
  return entry;
}
async function scanDevice(){
  const FS=capFS();
  if(!isNative()||!FS){toast('📲 Le scan du stockage n\'existe que dans l\'APK installé (impossible dans un navigateur).',6000);return;}
  // Autorisation de stockage (boîte de dialogue Android)
  try{
    let p=FS.checkPermissions?await FS.checkPermissions():null;
    if(!p||p.publicStorage!=='granted')p=await FS.requestPermissions();
    if(p&&p.publicStorage&&p.publicStorage!=='granted'){toast('🔒 Autorisation refusée. Activez l\'accès aux fichiers de RetroVault dans les réglages Android, puis relancez le scan.',7500);return;}
  }catch(e){/* certaines versions n'exposent pas check/request → on tente quand même */}
  toast('📲 Analyse du stockage en cours…',120000);
  const SKIP=/^(Android|DCIM|Pictures|Movies|Music|Alarms|Notifications|Ringtones|WhatsApp|Telegram|cache|LOST\.DIR|\.)/i;
  const found=[];
  async function walk(dir,path,depth){
    if(depth>7)return; // garde-fou
    let list;
    try{const r=await FS.readdir(dir?{path,directory:dir}:{path});list=r.files||[];}catch(e){return;}
    for(const ent of list){
      const nm=(typeof ent==='string')?ent:(ent&&ent.name);
      if(!nm)continue;
      const t=(typeof ent==='object'&&ent)?ent.type:null;
      const sz=(typeof ent==='object'&&ent)?(ent.size||0):0;
      const full=path?path+'/'+nm:nm;
      const isDir = t? (t==='directory') : !/\.[a-z0-9]{1,5}$/i.test(nm);
      if(isDir){ if(depth===0&&SKIP.test(nm))continue; await walk(dir,full,depth+1); }
      else { const ext=(nm.split('.').pop()||'').toLowerCase(); if(EXTS_SET.has(ext))found.push({dir,path:full,name:nm,size:sz}); }
    }
  }
  // 1) Stockage interne partagé (/storage/emulated/0)
  await walk('EXTERNAL_STORAGE','',0);
  // 2) Carte SD / autres volumes (best-effort, selon l'appareil)
  try{
    const r=await FS.readdir({path:'file:///storage'});
    for(const ent of (r.files||[])){
      const nm=(typeof ent==='string')?ent:(ent&&ent.name);
      if(!nm||/^(emulated|self)$/i.test(nm))continue;
      try{await walk(undefined,'file:///storage/'+nm,0);}catch(e){}
    }
  }catch(e){}
  if(!found.length){toast('📂 Aucune ROM trouvée. Placez vos jeux dans un dossier (ex. /Roms) puis relancez le scan.',7500);return;}
  const added=[];
  for(const f of found){const e=addScannedRom(f.name,f.size,f.dir,f.path);if(e)added.push(e);}
  saveLibMeta();renderConFilter();updateQuickStats();renderLib();navPage('page-lib');
  toast(`✅ ${added.length} ROM(s) trouvée(s) sur l'appareil`,5200);
  autoArt(added);
}
function updateQuickStats(){
  const qg=document.getElementById('qs-games'),qq=document.getElementById('qs-hb'),qs=document.getElementById('qs-saves');
  if(qg)qg.textContent=G.lib.length;
  if(qq)qq.textContent=G.lib.filter(g=>g.homebrew).length;
  if(qs)qs.textContent=G.savesCount;
  renderContinue();
}
function renderConFilter(){
  const el=document.getElementById('con-filter');if(!el)return;
  const used=[...new Set(G.lib.map(g=>g.consoleId))];
  el.innerHTML=`<div class="cf-chip ${!G.libCon?'on':''}" onclick="setLibCon('')">🎮 Tous</div>`+
    used.map(cid=>{const c=CONSOLES.find(c=>c.id===cid);return c?`<div class="cf-chip ${G.libCon===cid?'on':''}" onclick="setLibCon('${cid}')">${c.ico} ${c.name}</div>`:''}).join('');
}
function setLibCon(c){G.libCon=c;renderLib();renderConFilter();}
function setLibSort(v){G.libSort=v;renderLib();}
function renderLib(){
  const q=(document.getElementById('lib-q')?.value||'').toLowerCase();
  let items=G.lib;
  if(G.libCon)items=items.filter(g=>g.consoleId===G.libCon);
  if(q)items=items.filter(g=>g.name.toLowerCase().includes(q));
  // Tri : nom (défaut), console, ou récemment joués
  const sort=G.libSort||'name';
  items=[...items];
  if(sort==='con')items.sort((a,b)=>(a.consoleId||'').localeCompare(b.consoleId||'')||a.name.localeCompare(b.name));
  else if(sort==='recent')items.sort((a,b)=>(b.lastPlayed||0)-(a.lastPlayed||0)||a.name.localeCompare(b.name));
  else items.sort((a,b)=>a.name.localeCompare(b.name));
  const grid=document.getElementById('lib-grid');if(!grid)return;
  if(!items.length){grid.innerHTML=`<div style="grid-column:1/-1;text-align:center;padding:22px;color:#475569;font-size:.73rem">${q||G.libCon?'Aucun résultat':'Aucune ROM'}</div>`;return;}
  grid.innerHTML=items.map(g=>{
    const i=G.lib.indexOf(g);
    const con=CONSOLES.find(c=>c.id===g.consoleId);
    return `<div class="lc ${g.fav?'fav':''}" id="lc-${i}">
      <div class="lc-thumb" onclick="launchLib(${i})">
        ${g.artwork?`<img src="${esc(g.artwork)}" loading="lazy" onerror="this.remove()">`:`<span>${con?.ico||'🎮'}</span>`}
        <div class="lc-overlay"></div>
        ${g.homebrew?`<div class="lc-hb-badge">HB</div>`:`<div class="lc-cbadge">${con?.name||g.consoleId}</div>`}
        <div class="lc-play">▶</div>
        ${g.artLoading?`<div class="art-ov"><div class="mini-spin"></div></div>`:''}
        ${(g.stored===false&&!g.file)?`<div class="lc-warn" title="Fichier non stocké — réimportez la ROM">⚠️</div>`:''}
        <div class="lc-fav-ico">⭐</div>
        ${(G.saveSet&&G.saveSet.has(g.id))?`<div class="lc-save" title="Sauvegarde présente">💾</div>`:''}
      </div>
      <div class="lc-info">
        <div class="lc-name">${esc(g.name)}</div>
        <div class="lc-meta"><span class="lc-size">${g.size?(g.size/1024).toFixed(0)+' KB':'—'}${fmtPlay(g.playSecs)?' · ⏱ '+fmtPlay(g.playSecs):''}</span>
          <div class="lc-acts"><span class="lca" onclick="toggleFav(${i})">⭐</span><span class="lca" onclick="fetchOne(${i})">🖼</span><span class="lca" onclick="openGameOptions(${i})">⚙️</span><span class="lca" onclick="delLib(${i})">🗑</span></div>
        </div>
      </div>
    </div>`;
  }).join('');
}
async function launchLib(i){
  const g=G.lib[i];if(!g)return;
  if(g.file){loadROM(g.file,g.consoleId,g.id);return;}
  // ROM repérée sur le stockage (scan APK) : on lit le fichier à la volée depuis son chemin
  if(g.nativePath&&isNative()&&capFS()){
    try{
      showLoad('📂 Lecture du fichier…',12);
      const r=await capFS().readFile(g.nativeDir?{path:g.nativePath,directory:g.nativeDir}:{path:g.nativePath});
      const f=new File([b64ToBlob(r.data)],g.nativePath.split('/').pop());
      g.file=f;loadROM(f,g.consoleId,g.id);
    }catch(e){hideLoad();toast('⚠️ Lecture impossible : '+(e.message||e),5600);}
    return;
  }
  try{
    toast('📦 Chargement depuis le stockage…');
    const rec=await RVDB.getRom(g.id);
    const file=rec&&rec.blob?(rec.blob instanceof File?rec.blob:new File([rec.blob],rec.name||g.name,{type:rec.blob.type})):null;
    if(file){g.file=file;g.stored=true;loadROM(file,g.consoleId,g.id);}
    else{g.stored=false;renderLib();toast('⚠️ ROM absente du stockage — réimportez le fichier');}
  }catch(e){toast('❌ '+(e.message||e));}
}
function toggleFav(i){G.lib[i].fav=!G.lib[i].fav;saveLibMeta();renderLib();}
function delLib(i){const g=G.lib[i];if(g&&g.id){RVDB.delRom(g.id).catch(()=>{});deleteAllSaves(g.id);}G.lib.splice(i,1);saveLibMeta();renderLib();renderConFilter();updateQuickStats();}

// — Options par jeu : choix du core (émulateur) —
let gameOptIdx=null;
function openGameOptions(i){
  const g=G.lib[i];if(!g)return;gameOptIdx=i;
  const con=CONSOLES.find(c=>c.id===g.consoleId);
  document.getElementById('game-opt-title').textContent=g.name;
  document.getElementById('game-opt-sub').textContent=con?`${con.ico} ${con.full}`:g.consoleId;
  renderGameCores();
  openMo('mo-game');
}
function renderGameCores(){
  const g=G.lib[gameOptIdx];if(!g)return;
  const con=CONSOLES.find(c=>c.id===g.consoleId);const cores=con?con.cores:[];
  const cur=(g.core&&cores.includes(g.core))?g.core:cores[0];
  const box=document.getElementById('game-core-chips');if(!box)return;
  box.innerHTML=cores.length>1
    ? cores.map(c=>`<div class="sh-chip ${cur===c?'on':''}" onclick="setGameCore('${c}')">${c}</div>`).join('')
    : `<span style="font-size:.66rem;color:#64748b">Core unique : <strong style="color:#a78bfa">${cores[0]||'?'}</strong></span>`;
}
function setGameCore(c){
  const g=G.lib[gameOptIdx];if(!g)return;
  g.core=c;saveLibMeta();renderGameCores();toast('🔧 Core : '+c);
  if(g.id===G.curId)toast('↻ Relancez le jeu pour appliquer',2600);
}
function clearLib(){if(confirm('Effacer toute la bibliothèque ?')){G.lib.forEach(g=>{if(g.id){RVDB.delRom(g.id).catch(()=>{});deleteAllSaves(g.id);}});G.lib=[];saveLibMeta();renderLib();renderConFilter();updateQuickStats();toast('🗑 Effacée');}}

// ════════════════════════════════════════════════════
// API IMAGES
// ════════════════════════════════════════════════════
// libretro-thumbnails : boxart officielle, sans clé API. Le nom de système doit
// correspondre à la nomenclature libretro ; on tente quelques variantes de région.
const LIBRETRO_SYS={
  nes:'Nintendo - Nintendo Entertainment System',
  snes:'Nintendo - Super Nintendo Entertainment System',
  n64:'Nintendo - Nintendo 64',
  gb:'Nintendo - Game Boy',
  gbc:'Nintendo - Game Boy Color',
  gba:'Nintendo - Game Boy Advance',
  nds:'Nintendo - Nintendo DS',
  vb:'Nintendo - Virtual Boy',
  genesis:'Sega - Mega Drive - Genesis',
  mastersys:'Sega - Master System - Mark III',
  gamegear:'Sega - Game Gear',
  segacd:'Sega - Mega-CD - Sega CD',
  psx:'Sony - PlayStation',
  pce:'NEC - PC Engine - TurboGrafx 16',
  atari2600:'Atari - 2600',
  atari7800:'Atari - 7800',
  lynx:'Atari - Lynx',
  neogeo:'SNK - Neo Geo',
  ngp:'SNK - Neo Geo Pocket Color',
  neocd:'SNK - Neo Geo CD',
  coleco:'Coleco - ColecoVision',
  c64:'Commodore - 64',
  msx:'Microsoft - MSX',
  wonderswan:'Bandai - WonderSwan',
};
function probeImg(url){return new Promise(res=>{const im=new Image();let done=false;const fin=ok=>{if(!done){done=true;res(ok);}};im.onload=()=>fin(true);im.onerror=()=>fin(false);im.src=url;setTimeout(()=>fin(false),5000);});}
async function artLibretro(name,consoleId,raw){
  const sys=LIBRETRO_SYS[consoleId];if(!sys)return null;
  const base='https://thumbnails.libretro.com/'+encodeURIComponent(sys)+'/Named_Boxarts/';
  const san=s=>(s||'').replace(/[&*/:`<>?\\|]/g,'_').trim();
  const tries=[];
  const rawS=san(raw);
  if(rawS)tries.push(rawS); // nom de fichier exact : souvent la nomenclature No-Intro → correspondance directe
  const clean=san(name);
  if(clean){const variants=['',' (USA)',' (USA, Europe)',' (Europe)',' (Japan)',' (World)'];for(const v of variants)tries.push(clean+v);}
  const seen=new Set();
  for(const t of tries){
    if(!t||seen.has(t))continue;seen.add(t);
    const url=base+encodeURIComponent(t)+'.png';
    if(await probeImg(url))return url;
  }
  return null;
}
async function artRawg(n,rp){if(!G.rawgKey)return null;try{const q=encodeURIComponent(n);const p=rp&&rp!=='null'?`&platforms=${rp}`:'';let r=await fetch(`https://api.rawg.io/api/games?key=${G.rawgKey}&search=${q}&page_size=5${p}`,{signal:AbortSignal.timeout(6000)});if(r.ok){const d=await r.json();const h=(d.results||[]).find(g=>g.background_image&&softMatch(g.name,n))||(d.results||[]).find(g=>g.background_image);if(h?.background_image)return h.background_image;}r=await fetch(`https://api.rawg.io/api/games?key=${G.rawgKey}&search=${q}&page_size=3`,{signal:AbortSignal.timeout(5000)});if(r.ok){const d=await r.json();const h=(d.results||[]).find(g=>g.background_image&&softMatch(g.name,n));if(h?.background_image)return h.background_image;}}catch(e){}return null;}
async function artTGDB(n){try{const q=encodeURIComponent(n);const r=await fetch(`https://api.thegamesdb.net/v1/Games/ByGameName?apikey=legacy&name=${q}&fields=boxart`,{signal:AbortSignal.timeout(6000)});if(!r.ok)return null;const d=await r.json();const games=d.data?.games;if(!games?.length)return null;const base=d.include?.boxart?.base_url?.thumb||'https://cdn.thegamesdb.net/images/thumb/';const arts=d.include?.boxart?.data;if(!arts)return null;const id=games[0].id;const arr=arts[String(id)];if(!arr?.length)return null;const front=arr.find(a=>a.side==='front')||arr[0];return base+front.filename;}catch(e){}return null;}
async function artWiki(n){
  // Recherche floue (generator=search) puis image de la page — bien plus fiable qu'un titre exact.
  const get=async(query)=>{
    try{
      const r=await fetch(`https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrlimit=3&prop=pageimages&piprop=thumbnail&pithumbsize=400&format=json&origin=*`,{signal:AbortSignal.timeout(6000)});
      if(!r.ok)return null;
      const d=await r.json();
      const pages=Object.values(d.query?.pages||{}).sort((a,b)=>(a.index||9)-(b.index||9));
      for(const pg of pages){if(pg.thumbnail?.source)return pg.thumbnail.source;}
    }catch(e){}
    return null;
  };
  return await get(n+' video game')||await get(n);
}
async function fetchArt(g){if(g.artwork)return false;g.artLoading=true;const con=CONSOLES.find(c=>c.id===g.consoleId);try{const url=await artLibretro(g.name,g.consoleId,g.raw)||await artWiki(g.name)||await artRawg(g.name,con?.rp)||await artTGDB(g.name);if(url){g.artwork=url;g.artLoading=false;saveLibMeta();return true;}}catch(e){}g.artLoading=false;return false;}
async function fetchOne(i){const g=G.lib[i];if(!g)return;g.artwork=null;toast('🔍 Image…');renderLib();const ok=await fetchArt(g);toast(ok?'✅ Image trouvée':'⚠️ Aucune image');renderLib();}
async function fetchAllArt(){const m=G.lib.filter(g=>!g.artwork);if(!m.length){toast('✅ Déjà chargées');return;}toast(`🖼 ${m.length} images…`);for(let i=0;i<m.length;i++){await fetchArt(m[i]);if(i%3===0)renderLib();await sleep(100);}renderLib();toast('✅ Images récupérées');}
// Récupération AUTOMATIQUE des jaquettes pour les jeux fraîchement ajoutés (en arrière-plan).
// Affiche un spinner sur chaque vignette le temps de la recherche, puis l'image (ou l'icône console).
async function autoArt(list){
  const todo=(list||[]).filter(g=>g&&!g.artwork);
  if(!todo.length)return;
  const MAX=40;
  const batch=todo.slice(0,MAX);
  batch.forEach(g=>{g.artLoading=true;});
  renderLib();
  for(let i=0;i<batch.length;i++){
    await fetchArt(batch[i]);
    renderLib();
    await sleep(120);
  }
  if(todo.length>MAX)toast('🖼 Touchez « Images » pour charger les jaquettes restantes',4800);
}
function softMatch(a,b){const n=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'').substring(0,14);const na=n(a),nb=n(b);return na===nb||na.startsWith(nb.substring(0,8))||nb.startsWith(na.substring(0,8));}

// ════════════════════════════════════════════════════
// SAUVEGARDE / PAUSE
// ════════════════════════════════════════════════════
// Deux types de sauvegarde :
//   • SRAM  : la sauvegarde interne du jeu (menu "Save" du jeu, type Pokémon/Zelda).
//             Persistée automatiquement et réinjectée au lancement → permanente.
//   • Slots : des "save states" (instantané complet de l'émulateur). 3 slots manuels
//             (1,2,3) + 1 slot "auto" alimenté par l'auto-save.
const SLOTS=[1,2,3];
const SRAM_KEY=id=>`${id}:sram`;
const SLOT_KEY=(id,slot)=>`${id}:slot:${slot}`;

// — SRAM — sauvegarde silencieuse de la sauvegarde interne du jeu en cours
async function persistSRAM(){
  if(!G.inst||!G.running||!G.curId)return;
  try{
    const blob=await G.inst.saveSRAM();
    if(blob&&blob.size>0){await RVDB.putSave(SRAM_KEY(G.curId),{blob,at:Date.now()});if(G.saveSet)G.saveSet.add(G.curId);}
  }catch(e){/* certains jeux n'ont pas de SRAM : on ignore */}
}

// — Save states (slots) —
async function saveSlot(slot,quiet){
  if(!G.inst||!G.running){if(!quiet)toast('⚠️ Aucun jeu');return;}
  if(!G.curId){if(!quiet)toast('⚠️ Jeu non suivi');return;}
  try{
    const{state,thumbnail}=await G.inst.saveState();
    await RVDB.putSave(SLOT_KEY(G.curId,slot),{state,thumb:thumbnail||null,at:Date.now()});if(G.saveSet)G.saveSet.add(G.curId);
    if(slot!=='auto'){G.savesCount++;localStorage.setItem('rv_saves_count',G.savesCount);updateQuickStats();}
    if(!quiet){
      const b=document.getElementById('sv-banner');if(b){b.classList.add('on');setTimeout(()=>b.classList.remove('on'),1500);}
      toast('💾 Slot '+slot+' sauvegardé');
    }
    const mo=document.getElementById('mo-saves');if(mo&&mo.classList.contains('on'))renderSavesModal();
  }catch(e){if(!quiet)toast('❌ '+(e.message||e));}
}
async function loadSlot(slot){
  if(!G.inst||!G.running){toast('⚠️ Aucun jeu');return;}
  if(!G.curId)return;
  try{
    const rec=await RVDB.getSave(SLOT_KEY(G.curId,slot));
    if(!rec||!rec.state){toast('⚠️ Slot '+slot+' vide');return;}
    await G.inst.loadState(rec.state);
    toast(slot==='auto'?'↩️ Reprise auto':'📤 Slot '+slot+' chargé');
  }catch(e){toast('❌ '+(e.message||e));}
}
async function delSlot(slot){
  if(!G.curId)return;
  try{await RVDB.delSave(SLOT_KEY(G.curId,slot));toast('🗑 Slot '+slot+' effacé');renderSavesModal();}catch(e){}
}

// Boutons rapides (barre du haut + raccourcis manette/clavier) → slot 1
async function doSave(){saveSlot(1);}
async function doLoad(){loadSlot(1);}

async function doPause(){
  if(!G.inst||!G.running)return;
  try{
    if(G.paused){await G.inst.resume();G.paused=false;document.getElementById('btn-pause').textContent='⏸';toast('▶ Reprise');}
    else{await G.inst.pause();G.paused=true;document.getElementById('btn-pause').textContent='▶';persistSRAM();toast('⏸ Pause');}
  }catch(e){}
}

// — Auto-save loop — SRAM toutes les 30 s ; save state auto toutes les 60 s (si activé)
function startAutoLoop(){
  stopAutoLoop();
  let tick=0;
  G.autoTimer=setInterval(()=>{
    if(!G.running||G.paused)return;
    tick++;
    persistSRAM();
    if(G.cfg.autosave&&tick%2===0)saveSlot('auto',true);
  },30000);
}
function stopAutoLoop(){if(G.autoTimer){clearInterval(G.autoTimer);G.autoTimer=null;}}

// — Modale de gestion des slots —
let savesUrls=[];
function revokeSavesUrls(){savesUrls.forEach(u=>{try{URL.revokeObjectURL(u);}catch(e){}});savesUrls=[];}
async function openSaves(){
  if(!G.running||!G.curId){toast('⚠️ Lancez un jeu d’abord');return;}
  openMo('mo-saves');renderSavesModal();
}
async function renderSavesModal(){
  const box=document.getElementById('saves-content');if(!box)return;
  document.getElementById('saves-sub').textContent=G.curName?`Jeu : ${G.curName}`:'Slots du jeu en cours';
  revokeSavesUrls();
  const keys=['auto',...SLOTS];
  const rows=await Promise.all(keys.map(async slot=>{
    let rec=null;try{rec=await RVDB.getSave(SLOT_KEY(G.curId,slot));}catch(e){}
    const has=!!(rec&&rec.state);
    let thumbHtml='<span>💾</span>';
    if(has&&rec.thumb){const u=URL.createObjectURL(rec.thumb);savesUrls.push(u);thumbHtml=`<img src="${u}">`;}
    const when=has?new Date(rec.at).toLocaleString():'';
    const label=slot==='auto'?'⚙️ Auto':'Slot '+slot;
    return `<div class="slot-row">
      <div class="slot-thumb">${thumbHtml}</div>
      <div class="slot-info"><div class="slot-name">${label}</div><div class="slot-when">${has?esc(when):'— vide —'}</div></div>
      <div class="slot-acts">
        ${slot==='auto'?'':`<button class="slot-btn" onclick="saveSlot(${slot})">💾</button>`}
        <button class="slot-btn ${has?'':'dis'}" ${has?'':'disabled'} onclick="loadSlot('${slot}')">📤</button>
        <button class="slot-btn ${has?'':'dis'}" ${has?'':'disabled'} onclick="delSlot('${slot}')">🗑</button>
      </div>
    </div>`;
  }));
  box.innerHTML=rows.join('');
}
// Supprime toutes les sauvegardes (SRAM + slots) d'un jeu — utilisé à la suppression
async function deleteAllSaves(id){
  try{const all=await RVDB.saveKeys();await Promise.all(all.filter(k=>typeof k==='string'&&k.startsWith(id+':')).map(k=>RVDB.delSave(k)));}catch(e){}
}

// ════════════════════════════════════════════════════
// CONTRÔLEUR TACTILE
// ════════════════════════════════════════════════════
function pressDown(id){const n=BTN_MAP[id];if(!n||G.held.has(id))return;G.held.add(id);document.getElementById(id)?.classList.add('pr');if(G.inst&&G.running&&!G.paused)G.inst.pressDown(n).catch(()=>{});if(G.cfg.haptic&&navigator.vibrate)navigator.vibrate(10);}
function pressUp(id){const n=BTN_MAP[id];if(!n)return;G.held.delete(id);document.getElementById(id)?.classList.remove('pr');if(G.inst&&G.running)G.inst.pressUp(n).catch(()=>{});}
function releaseAll(){G.held.forEach(id=>pressUp(id));}
function pickROM(){document.getElementById('inp-file').value='';document.getElementById('inp-file').click();}

// ════════════════════════════════════════════════════
// STICK ANALOGIQUE TACTILE
// ════════════════════════════════════════════════════
// Le thumbstick pilote toujours la croix numérique (fiable, menus + jeux à croix).
// Sur les consoles à stick (N64, PS1), il pilote EN PLUS le vrai stick analogique
// gauche, via les axes RetroArch mappés sur les touches i/j/k/l (cf. loadROM) que
// l'on déclenche par des événements clavier synthétiques.
const ANALOG_KEYS={up:['i','KeyI',73],down:['k','KeyK',75],left:['j','KeyJ',74],right:['l','KeyL',76]};
function analogKey(dir,down){
  const m=ANALOG_KEYS[dir];if(!m)return;
  const ev=new KeyboardEvent(down?'keydown':'keyup',{key:m[0],code:m[1],keyCode:m[2],which:m[2],bubbles:true,cancelable:true});
  document.dispatchEvent(ev);
}
const STICK_DPAD={up:'btn-up',down:'btn-down',left:'btn-left',right:'btn-right'};
function stickPress(dir,down){
  const id=STICK_DPAD[dir];
  if(down)pressDown(id);else pressUp(id);   // croix numérique (universel)
  if(G.analogMode)analogKey(dir,down);       // + stick analogique (N64/PS1)
}
function applyAnalogStick(){const c=document.getElementById('touch-ctrl');if(c)c.classList.toggle('analog',!!G.cfg.analogstick);}

// ════════════════════════════════════════════════════
// REMAPPING CLAVIER & PERSONNALISATION MANETTE TACTILE
// ════════════════════════════════════════════════════
const BTN_LABELS={'btn-up':'Haut ▲','btn-down':'Bas ▼','btn-left':'Gauche ◀','btn-right':'Droite ▶','btn-A':'A','btn-B':'B','btn-X':'X','btn-Y':'Y','btn-L':'L','btn-R':'R','btn-start':'Start','btn-select':'Select'};
const KEY_ORDER=['btn-up','btn-down','btn-left','btn-right','btn-A','btn-B','btn-X','btn-Y','btn-L','btn-R','btn-start','btn-select'];
function keyLabel(k){
  if(k===' ')return 'Espace';
  if(k==='Enter')return 'Entrée';
  if(k==='ArrowUp')return '↑';if(k==='ArrowDown')return '↓';if(k==='ArrowLeft')return '←';if(k==='ArrowRight')return '→';
  if(!k)return '—';
  return k.length===1?k.toUpperCase():k;
}
function renderKeymap(){
  const box=document.getElementById('keymap-list');if(!box)return;
  box.innerHTML=KEY_ORDER.map(bid=>{
    const listening=G.rebindTarget===bid;
    return `<div class="km-row ${listening?'listening':''}">
      <span class="km-btn">${BTN_LABELS[bid]||bid}</span>
      <span class="km-key" onclick="startRebind('${bid}')">${listening?'Appuyez sur une touche…':esc(keyLabel(G.keys[bid]))}</span>
    </div>`;
  }).join('');
}
function startRebind(bid){
  G.rebindTarget=G.rebindTarget===bid?null:bid;
  renderKeymap();
}
// Capture la prochaine touche pour la réassigner (appelée depuis le keydown global)
function captureRebind(e){
  if(e.key==='Escape'){G.rebindTarget=null;renderKeymap();return;}
  if(['Shift','Control','Alt','Meta'].includes(e.key))return; // attend une vraie touche
  const bid=G.rebindTarget;
  // retire cette touche d'un éventuel autre bouton (pas de doublon)
  Object.keys(G.keys).forEach(k=>{if(G.keys[k]===e.key)G.keys[k]='';});
  G.keys[bid]=e.key;
  G.rebindTarget=null;
  saveKeys();renderKeymap();
  toast(`✅ ${BTN_LABELS[bid]} → ${keyLabel(e.key)}`);
}
function resetKeys(){G.keys={...DEFAULT_KEYS};G.rebindTarget=null;saveKeys();renderKeymap();toast('↩️ Touches réinitialisées');}

// — Personnalisation de la manette tactile (taille / opacité / gaucher) —
function applyCtrlCustom(){
  const c=document.getElementById('touch-ctrl');if(!c)return;
  c.classList.remove('cs-sm','cs-lg');
  if(G.cfg.ctrlScale==='sm')c.classList.add('cs-sm');
  else if(G.cfg.ctrlScale==='lg')c.classList.add('cs-lg');
  c.classList.toggle('lefty',!!G.cfg.lefty);
  c.style.setProperty('--ctrl-op',String(G.cfg.ctrlOpacity!=null?G.cfg.ctrlOpacity:1));
}
function setCtrlScale(s){G.cfg.ctrlScale=s;savePrefs();applyCtrlCustom();renderCtrlCustom();}
function setCtrlOpacity(v){G.cfg.ctrlOpacity=Math.max(.3,Math.min(1,parseFloat(v)||1));savePrefs();applyCtrlCustom();}
function renderCtrlCustom(){
  const box=document.getElementById('ctrl-size-chips');if(box){
    const opts=[['sm','Petit'],['md','Normal'],['lg','Grand']];
    box.innerHTML=opts.map(([k,n])=>`<div class="sh-chip ${G.cfg.ctrlScale===k?'on':''}" onclick="setCtrlScale('${k}')">${n}</div>`).join('');
  }
  const op=document.getElementById('ctrl-opacity');if(op)op.value=String(G.cfg.ctrlOpacity!=null?G.cfg.ctrlOpacity:1);
}
function bindStick(){
  const base=document.getElementById('stick-base'),knob=document.getElementById('stick-knob');
  if(!base||!knob)return;
  let active=false;const cur=new Set();
  function setDirs(want){
    ['up','down','left','right'].forEach(d=>{
      if(want.has(d)&&!cur.has(d)){cur.add(d);stickPress(d,true);}
      else if(!want.has(d)&&cur.has(d)){cur.delete(d);stickPress(d,false);}
    });
  }
  function move(cx,cy){
    const r=base.getBoundingClientRect();
    const ox=r.left+r.width/2,oy=r.top+r.height/2,max=r.width/2;
    let dx=cx-ox,dy=cy-oy;const dist=Math.hypot(dx,dy);
    if(dist>max){dx=dx/dist*max;dy=dy/dist*max;}
    knob.style.transform=`translate(${dx}px,${dy}px)`;
    const dead=max*0.30,th=dead*0.8;const want=new Set();
    if(dist>dead){
      if(dx<-th)want.add('left');else if(dx>th)want.add('right');
      if(dy<-th)want.add('up');else if(dy>th)want.add('down');
    }
    setDirs(want);
  }
  base.addEventListener('pointerdown',e=>{e.preventDefault();active=true;try{base.setPointerCapture(e.pointerId);}catch(_){}move(e.clientX,e.clientY);if(G.cfg.haptic&&navigator.vibrate)navigator.vibrate(8);},{passive:false});
  base.addEventListener('pointermove',e=>{if(active){e.preventDefault();move(e.clientX,e.clientY);}},{passive:false});
  const end=()=>{active=false;knob.style.transform='';setDirs(new Set());};
  base.addEventListener('pointerup',end);
  base.addEventListener('pointercancel',end);
  base.addEventListener('touchstart',e=>e.preventDefault(),{passive:false});
  base.addEventListener('touchmove',e=>e.preventDefault(),{passive:false});
}

// ════════════════════════════════════════════════════
// BIOS (fichiers système requis par PS1, Sega CD, Neo Geo…)
// ════════════════════════════════════════════════════
function pickBios(){const i=document.getElementById('inp-bios');i.value='';i.click();}
async function addBios(files){
  let n=0;
  for(const f of Array.from(files)){
    try{await RVDB.putBios(f.name,f);n++;}catch(e){toast('⚠️ '+(e.message||e));}
  }
  if(n)toast(`✅ ${n} BIOS ajouté(s)`);
  renderBiosList();
}
async function delBios(name){try{await RVDB.delBios(name);toast('🗑 BIOS supprimé');renderBiosList();}catch(e){}}
let biosCache=[];
function delBiosAt(i){const b=biosCache[i];if(b)delBios(b.name);}
async function renderBiosList(){
  const box=document.getElementById('bios-list');if(!box)return;
  let list=[];try{list=await RVDB.getAllBios();}catch(e){}
  biosCache=(list||[]).filter(Boolean);
  if(!biosCache.length){box.innerHTML='<div style="font-size:.66rem;color:#475569;padding:4px 2px">Aucun BIOS. Ajoutez les fichiers que vous possédez légalement.</div>';return;}
  box.innerHTML=biosCache.map((b,i)=>`<div class="bios-row">
    <div class="bios-ico">📦</div>
    <div class="bios-info"><div class="bios-name">${esc(b.name)}</div><div class="bios-size">${b.size?(b.size/1024).toFixed(0)+' KB':''}</div></div>
    <span class="bios-del" onclick="delBiosAt(${i})">🗑</span>
  </div>`).join('');
}

// ════════════════════════════════════════════════════
// INSTALLATION PWA
// ════════════════════════════════════════════════════
let deferredPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();deferredPrompt=e;
  const b=document.getElementById('btn-install');if(b)b.style.display='block';
});
window.addEventListener('appinstalled',()=>{
  deferredPrompt=null;
  const b=document.getElementById('btn-install');if(b)b.style.display='none';
  toast('✅ RetroVault installé');
});
function triggerInstall(){
  if(!deferredPrompt){toast('ℹ️ Utilisez le menu du navigateur pour installer');return;}
  deferredPrompt.prompt();
  deferredPrompt.userChoice.finally(()=>{deferredPrompt=null;const b=document.getElementById('btn-install');if(b)b.style.display='none';});
}

// ════════════════════════════════════════════════════
// EXPORT / IMPORT DE LA BIBLIOTHÈQUE (.zip)
// ════════════════════════════════════════════════════
// JSZip est chargé à la demande (pas au démarrage) ; mis en cache par le SW.
let jszipPromise=null;
function loadJSZip(){
  if(window.JSZip)return Promise.resolve(window.JSZip);
  if(jszipPromise)return jszipPromise;
  jszipPromise=new Promise((resolve,reject)=>{
    const s=document.createElement('script');
    s.src='https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js';
    s.crossOrigin='anonymous';
    s.onload=()=>resolve(window.JSZip);
    s.onerror=()=>{jszipPromise=null;reject(new Error('JSZip introuvable (connexion requise la 1ʳᵉ fois)'));};
    document.head.appendChild(s);
  });
  return jszipPromise;
}
function extOf(name){const m=(name||'').split('.').pop();return (m&&m.length<=5)?m.toLowerCase():'bin';}

async function exportBackup(withRoms){
  if(G.busyBackup)return;G.busyBackup=true;
  try{
    toast('📦 Préparation de la sauvegarde…',4000);
    const JSZip=await loadJSZip();
    const zip=new JSZip();
    const manifest={app:'RetroVault',format:1,exportedAt:Date.now(),savesCount:G.savesCount,
      cfg:G.cfg,keys:G.keys,
      lib:G.lib.map(({file,artLoading,stored,...r})=>r),
      roms:[],saves:[],bios:[]};
    // ROMs (optionnel)
    if(withRoms){
      let n=0;
      for(const g of G.lib){
        try{const rec=await RVDB.getRom(g.id);const blob=rec&&rec.blob;if(blob){const path=`roms/${g.id}.${extOf(rec.name||g.name)}`;zip.file(path,blob);manifest.roms.push({id:g.id,path,name:rec.name||g.name});}}catch(e){}
        n++;
      }
    }
    // Sauvegardes (SRAM + slots)
    let si=0;
    try{
      const skeys=await RVDB.saveKeys();
      for(const key of skeys){
        const rec=await RVDB.getSave(key);if(!rec)continue;
        if(/:sram$/.test(key)&&rec.blob){const p=`saves/${si}.sram`;zip.file(p,rec.blob);manifest.saves.push({key,kind:'sram',at:rec.at||0,blob:p});si++;}
        else if(/:slot:/.test(key)&&rec.state){const ps=`saves/${si}.state`;zip.file(ps,rec.state);const e={key,kind:'slot',at:rec.at||0,state:ps};if(rec.thumb){const pt=`saves/${si}.thumb`;zip.file(pt,rec.thumb);e.thumb=pt;}manifest.saves.push(e);si++;}
      }
    }catch(e){}
    // BIOS
    try{const all=await RVDB.getAllBios();for(const b of (all||[])){if(b&&b.blob){const p=`bios/${b.name}`;zip.file(p,b.blob);manifest.bios.push({name:b.name,path:p});}}}catch(e){}
    zip.file('manifest.json',JSON.stringify(manifest));
    const blob=await zip.generateAsync({type:'blob',compression:'STORE'});
    const d=new Date();const stamp=`${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`retrovault-backup-${stamp}.zip`;a.click();
    setTimeout(()=>URL.revokeObjectURL(a.href),4000);
    toast(`✅ Sauvegarde exportée (${(blob.size/1048576).toFixed(1)} Mo)`);
  }catch(e){toast('❌ '+(e.message||e));}
  G.busyBackup=false;
}

function pickImport(){const i=document.getElementById('inp-import');i.value='';i.click();}
async function importBackup(file){
  if(!file||G.busyBackup)return;G.busyBackup=true;
  try{
    toast('📥 Lecture de la sauvegarde…',4000);
    const JSZip=await loadJSZip();
    const zip=await JSZip.loadAsync(file);
    const mf=zip.file('manifest.json');
    if(!mf)throw new Error('Fichier invalide (manifest manquant)');
    const manifest=JSON.parse(await mf.async('string'));
    if(manifest.app!=='RetroVault')throw new Error('Sauvegarde non reconnue');

    // 1) Préférences + touches
    if(manifest.cfg)Object.assign(G.cfg,manifest.cfg);
    if(manifest.keys)G.keys={...DEFAULT_KEYS,...manifest.keys};
    savePrefs();saveKeys();

    // 2) Bibliothèque (préserve les ids ; remappe les doublons par nom)
    const idRemap={};let addedGames=0;
    for(const g of (manifest.lib||[])){
      const byId=G.lib.find(x=>x.id===g.id);
      if(byId){idRemap[g.id]=g.id;continue;}
      const byName=G.lib.find(x=>x.name===g.name);
      if(byName){idRemap[g.id]=byName.id;continue;}
      idRemap[g.id]=g.id;
      G.lib.push({...g,file:null,artLoading:false,stored:false});
      addedGames++;
    }

    // 3) ROMs
    for(const r of (manifest.roms||[])){
      const f=zip.file(r.path);if(!f)continue;
      const blob=await f.async('blob');
      const id=idRemap[r.id]||r.id;
      try{await RVDB.putRom(id,new File([blob],r.name||(id+'.bin')));}catch(e){}
    }

    // 4) Sauvegardes (remappe le préfixe d'id de la clé)
    let addedSaves=0;
    for(const s of (manifest.saves||[])){
      const idx=s.key.indexOf(':');if(idx<0)continue;
      const oldId=s.key.slice(0,idx);const rest=s.key.slice(idx);
      const newKey=(idRemap[oldId]||oldId)+rest;
      try{
        if(s.kind==='sram'&&s.blob){const b=await zip.file(s.blob).async('blob');await RVDB.putSave(newKey,{blob:b,at:s.at||0});addedSaves++;}
        else if(s.kind==='slot'&&s.state){const st=await zip.file(s.state).async('blob');const val={state:st,thumb:null,at:s.at||0};if(s.thumb&&zip.file(s.thumb))val.thumb=await zip.file(s.thumb).async('blob');await RVDB.putSave(newKey,val);addedSaves++;}
      }catch(e){}
    }

    // 5) BIOS
    for(const b of (manifest.bios||[])){
      const f=zip.file(b.path);if(!f)continue;
      try{await RVDB.putBios(b.name,new File([await f.async('blob')],b.name));}catch(e){}
    }

    // 6) Réappliquer / rafraîchir l'UI
    Object.keys(G.cfg).forEach(k=>{const el=document.getElementById('tog-'+k);if(el)el.classList.toggle('on',!!G.cfg[k]);});
    rebuildKeymap();
    G.savesCount=Math.max(G.savesCount,manifest.savesCount||0);localStorage.setItem('rv_saves_count',G.savesCount);
    applyHideTouchCtrl();applyFpsCounter();applyAnalogStick();applyCtrlCustom();
    if(G.rawgKey){const rk=document.getElementById('rawg-key');if(rk)rk.value=G.rawgKey;}
    saveLibMeta();updateQuickStats();renderLib();renderConFilter();
    renderKeymap();renderCtrlCustom();renderBiosList();renderShaderChips();
    await reconcileStorage();
    toast(`✅ Importé : ${addedGames} jeu(x), ${addedSaves} sauvegarde(s)`,4000);
  }catch(e){toast('❌ '+(e.message||e),4000);}
  G.busyBackup=false;
}

function bindUI(){
  document.getElementById('btn-save') .addEventListener('click',doSave);
  document.getElementById('btn-load') .addEventListener('click',doLoad);
  document.getElementById('btn-pause').addEventListener('click',doPause);
  document.getElementById('btn-cfg')  .addEventListener('click',()=>navPage('page-cfg'));
  document.getElementById('btn-saves').addEventListener('click',openSaves);
  document.getElementById('btn-home-pick').addEventListener('click',pickROM);
  document.getElementById('btn-add-roms').addEventListener('click',pickROM);
  document.getElementById('btn-add-zip').addEventListener('click',()=>{const i=document.getElementById('inp-romzip');i.value='';i.click();});
  document.getElementById('inp-romzip').addEventListener('change',e=>{if(e.target.files[0])importZipOfRoms(e.target.files[0]);});
  // APK natif : bouton de scan du stockage + scan auto au 1er lancement (bibliothèque vide)
  if(isNative()){
    const sb=document.getElementById('btn-scan-device');
    if(sb){sb.style.display='';sb.addEventListener('click',()=>scanDevice());}
    if(!G.lib.length)setTimeout(()=>scanDevice(),1400);
  }
  document.getElementById('btn-all-art').addEventListener('click',fetchAllArt);
  document.getElementById('inp-file').addEventListener('change',e=>{if(e.target.files.length)addFiles(e.target.files);});
  document.getElementById('inp-folder').addEventListener('change',e=>addFiles(e.target.files));
  document.getElementById('btn-add-bios').addEventListener('click',pickBios);
  document.getElementById('inp-bios').addEventListener('change',e=>{if(e.target.files.length)addBios(e.target.files);});
  document.getElementById('btn-ff').addEventListener('pointerdown',e=>{e.preventDefault();doFastForward();},{passive:false});
  // ⏪ rembobinage maintenu
  const rw=document.getElementById('btn-rw');
  if(rw){
    rw.addEventListener('pointerdown',e=>{e.preventDefault();rw.setPointerCapture(e.pointerId);startRewind();},{passive:false});
    ['pointerup','pointercancel','pointerleave'].forEach(ev=>rw.addEventListener(ev,stopRewind));
  }
  const tb=document.getElementById('btn-turbo');if(tb)tb.addEventListener('pointerdown',e=>{e.preventDefault();toggleTurbo();},{passive:false});
  const sh=document.getElementById('btn-shot');if(sh)sh.addEventListener('click',takeShot);
  const ia=document.getElementById('inp-art');if(ia)ia.addEventListener('change',e=>{if(e.target.files[0])onArtPicked(e.target.files[0]);});
  const gv=document.getElementById('game-vol');
  if(gv){gv.addEventListener('input',e=>setGameVol(e.target.value));gv.value=String(G.cfg.volume!=null?G.cfg.volume:100);const gl=document.getElementById('game-vol-lab');if(gl)gl.textContent=(G.cfg.volume!=null?G.cfg.volume:100)+'%';}
  // Badge 💾 : quels jeux ont une sauvegarde ?
  G.saveSet=new Set();
  if(window.RVDB&&RVDB.saveKeys)RVDB.saveKeys().then(ks=>{G.saveSet=new Set((ks||[]).map(k=>String(k).split(':')[0]));renderLib();}).catch(()=>{});
  renderContinue();
  const sa=document.getElementById('shader-apply');if(sa)sa.addEventListener('click',reloadCurrent);
  const bi=document.getElementById('btn-install');if(bi)bi.addEventListener('click',triggerInstall);
  const op=document.getElementById('ctrl-opacity');if(op)op.addEventListener('input',e=>setCtrlOpacity(e.target.value));
  const rk=document.getElementById('btn-reset-keys');if(rk)rk.addEventListener('click',resetKeys);
  const ii=document.getElementById('inp-import');if(ii)ii.addEventListener('change',e=>{if(e.target.files.length)importBackup(e.target.files[0]);});
  const gl=document.getElementById('game-launch');if(gl)gl.addEventListener('click',()=>{const i=gameOptIdx;closeMo(null,'mo-game');if(i!=null)launchLib(i);});
  Object.keys(BTN_MAP).forEach(id=>{
    const el=document.getElementById(id);if(!el)return;
    el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);pressDown(id);},{passive:false});
    el.addEventListener('pointerup',  e=>{e.preventDefault();pressUp(id);},{passive:false});
    el.addEventListener('pointercancel',()=>pressUp(id));
    el.addEventListener('pointerleave',e=>{if(!el.hasPointerCapture(e.pointerId))pressUp(id);});
  });
  document.querySelector('.ctrl').addEventListener('touchstart',e=>e.preventDefault(),{passive:false});
  document.querySelector('.ctrl').addEventListener('touchmove', e=>e.preventDefault(),{passive:false});
  window.addEventListener('blur',releaseAll);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){releaseAll();persistSRAM();}});
  window.addEventListener('pagehide',()=>{persistSRAM();});
}
function bindKeys(){
  document.addEventListener('keydown',e=>{
    if(G.rebindTarget){captureRebind(e);e.preventDefault();return;}
    const id=KEYMAP[e.key];if(id){pressDown(id);e.preventDefault();}
    // Raccourcis clavier supplémentaires
    if(e.key==='F5'||e.key==='s'&&e.ctrlKey){doSave();e.preventDefault();}
    if(e.key==='F9'||e.key==='l'&&e.ctrlKey){doLoad();e.preventDefault();}
    if(e.key==='Escape'){doPause();}
    if(e.key==='r'&&G.cfg.rewind&&G.inst&&G.running){startRewind();e.preventDefault();}
    if(e.key==='f'&&G.inst&&G.running){doFastForward();e.preventDefault();}
  });
  document.addEventListener('keyup',e=>{
    const id=KEYMAP[e.key];if(id)pressUp(id);
    if(e.key==='r')stopRewind();
  });
}
function bindResize(){const ro=new ResizeObserver(()=>{if(G.inst&&G.running){const{width,height}=getSize();G.inst.resize({width,height}).catch(()=>{});}});ro.observe(document.getElementById('screen-zone'));}
function getSize(){const z=document.getElementById('screen-zone');return{width:Math.round(z.clientWidth),height:Math.round(z.clientHeight)};}

// ════════════════════════════════════════════════════
// SETTINGS
// ════════════════════════════════════════════════════
function togCfg(k){
  const el=document.getElementById('tog-'+k);el.classList.toggle('on');G.cfg[k]=el.classList.contains('on');savePrefs();
  if(k==='hidetouchctrl')applyHideTouchCtrl();
  if(k==='fps')applyFpsCounter();
  if(k==='analogstick')applyAnalogStick();
  if(k==='lefty')applyCtrlCustom();
  if(k==='music'){musicArmed=true;syncMusicUI();updateMusicState();toast(G.cfg.music?'🎵 Musique du menu activée':'🔇 Musique du menu coupée');return;}
  toast(`${G.cfg[k]?'✅':'❌'} ${k}`);
}
function applyHideTouchCtrl(){
  const ctrl=document.getElementById('touch-ctrl');
  if(!ctrl)return;
  ctrl.style.display=(G.cfg.hidetouchctrl&&G.gpIdx!==null)?'none':'';
}
function applyFpsCounter(){
  const fc=document.getElementById('fps-counter');
  if(fc)fc.classList.toggle('on',G.cfg.fps&&G.running);
}
function saveKey(){const k=document.getElementById('rawg-key').value.trim();G.rawgKey=k;localStorage.setItem('rawg_key',k);setApiSt(!!k);toast(k?'✅ Clé RAWG sauvegardée':'⚠️ Vide');}
function setApiSt(ok){const el=document.getElementById('api-st');if(!el)return;el.className='api-st '+(ok?'api-ok':'api-ko');el.textContent=ok?'✓ Libretro + RAWG + TheGamesDB + Wikipedia':'Libretro + TheGamesDB + Wikipedia actifs';}

// ════════════════════════════════════════════════════
// MODALS
// ════════════════════════════════════════════════════
function openMo(id){document.getElementById(id).classList.add('on');}
function closeMo(e,id){if(!e||e.target.id===id)document.getElementById(id).classList.remove('on');}
function showLoad(msg,pct){document.getElementById('loading').classList.add('on');document.getElementById('ld-msg').textContent=msg;document.getElementById('ld-fill').style.width=pct+'%';}
function hideLoad(){document.getElementById('loading').classList.remove('on');}
function toast(msg,dur=2600){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('on'),dur);}
function cleanName(f){return f.replace(/\.[^.]+$/,'').replace(/[\(\[\{][^\)\]\}]*[\)\]\}]/g,'').replace(/[-_]/g,' ').replace(/\s+/g,' ').trim();}
function esc(s){return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
