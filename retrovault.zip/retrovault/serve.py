#!/usr/bin/env python3
"""
Serveur de développement local pour RetroVault.

RetroArch WASM (Nostalgist.js) a besoin de SharedArrayBuffer, donc de
l'isolation cross-origin. Ce petit serveur ajoute les en-têtes COOP/COEP
que `python3 -m http.server` n'envoie PAS.

Usage :
    python3 serve.py [port]      # port par défaut : 8000

Puis ouvrez http://localhost:8000
"""
import sys
import http.server
import socketserver

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
        super().end_headers()


with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"RetroVault en cours d'exécution → http://localhost:{PORT}")
    print("Ctrl+C pour arrêter.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêté.")
