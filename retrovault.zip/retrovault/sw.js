/*
 * RetroVault — Service Worker
 *
 * Trois rôles :
 *   1. Hors-ligne : précache du « shell » de l'app (HTML/CSS/JS/icônes).
 *   2. Cache des cores : met en cache à la volée les fichiers chargés depuis
 *      jsDelivr (cores RetroArch), pour rejouer une console déjà utilisée hors-ligne.
 *   3. Isolation cross-origin : injecte les en-têtes COOP/COEP requis par
 *      SharedArrayBuffer (RetroArch WASM) — ce qui rend l'app fonctionnelle même
 *      sur des hébergeurs sans en-têtes personnalisés, comme GitHub Pages.
 *
 * On utilise COEP "credentialless" (et non "require-corp") pour que les images
 * cross-origin (jaquettes RAWG/Wikipedia, miniatures homebrew) continuent de
 * se charger tout en gardant l'isolation cross-origin.
 */
'use strict';

const VERSION = 'v25';
const SHELL_CACHE = 'rv-shell-' + VERSION;
const CDN_CACHE = 'rv-cdn-' + VERSION;

const SHELL = [
  './',
  './index.html',
  './css/styles.css',
  './js/db.js',
  './js/app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png',
  './icons/icon-180.png',
  './icons/favicon-32.png',
  './icons/logo.png',
  './icons/wordmark.png',
  './icons/og-image.jpg',
  './assets/bg.jpg',
];

// Médias volumineux (musique) : mis en cache séparément, sans bloquer ni faire
// échouer le cache critique si un téléchargement est interrompu.
const MEDIA = [
  './assets/music-1.mp3',
  './assets/music-2.mp3',
];

// Icônes de consoles : préchargées en best-effort.
const CON_IDS = ['nes','snes','gb','gbc','gba','genesis','mastersys','gamegear','psx','pce','neogeo','neocd','arcade','segacd','lynx','ngp','vb','msx','coleco','c64','wonderswan','n64','nds','atari2600','atari7800','dos'];
const ICONS = CON_IDS.map((id) => './icons/consoles/' + id + '.png?v=8');

self.addEventListener('install', (e) => {
  self.skipWaiting();
  e.waitUntil((async () => {
    const c = await caches.open(SHELL_CACHE);
    await c.addAll(SHELL).catch(() => {});   // coquille critique
    c.addAll(MEDIA).catch(() => {});         // musique : best-effort
    c.addAll(ICONS).catch(() => {});         // icônes consoles : best-effort
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== SHELL_CACHE && k !== CDN_CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});

// Ajoute les en-têtes d'isolation cross-origin à une réponse (document/shell).
function withCOI(resp) {
  if (!resp || resp.status === 0 || resp.type === 'opaque') return resp;
  const h = new Headers(resp.headers);
  h.set('Cross-Origin-Embedder-Policy', 'credentialless');
  h.set('Cross-Origin-Opener-Policy', 'same-origin');
  h.set('Cross-Origin-Resource-Policy', 'cross-origin');
  return new Response(resp.body, { status: resp.status, statusText: resp.statusText, headers: h });
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // 1) Navigation : réseau d'abord (+ en-têtes COI), repli sur le shell en cache
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const net = await fetch(req);
        const c = await caches.open(SHELL_CACHE);
        c.put('./index.html', net.clone()).catch(() => {});
        return withCOI(net);
      } catch (_) {
        const cached = (await caches.match(req)) || (await caches.match('./index.html'));
        return cached ? withCOI(cached) : Response.error();
      }
    })());
    return;
  }

  // 2) Même origine (shell) : cache d'abord (+ COI), repli réseau
  if (url.origin === self.location.origin) {
    e.respondWith((async () => {
      const cached = await caches.match(req);
      if (cached) return withCOI(cached);
      try {
        const net = await fetch(req);
        if (net.ok) { const c = await caches.open(SHELL_CACHE); c.put(req, net.clone()).catch(() => {}); }
        return withCOI(net);
      } catch (_) {
        return cached || Response.error();
      }
    })());
    return;
  }

  // 3) jsDelivr (cores RetroArch) : stale-while-revalidate, pour le hors-ligne
  if (/(^|\.)jsdelivr\.net$/.test(url.hostname)) {
    e.respondWith((async () => {
      const cache = await caches.open(CDN_CACHE);
      const cached = await cache.match(req);
      const network = fetch(req).then((net) => {
        if (net && net.ok) cache.put(req, net.clone()).catch(() => {});
        return net;
      }).catch(() => cached);
      return cached || network;
    })());
    return;
  }

  // 4) Reste (jaquettes, miniatures…) : réseau direct, pas de cache ni de réécriture
});
