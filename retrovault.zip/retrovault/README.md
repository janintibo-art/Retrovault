# 🎮 RetroVault

> Émulateur rétro **multi-console** dans le navigateur — manette physique, save states, rewind et catalogue homebrew légal.

RetroVault est une application web 100 % côté client construite sur
[Nostalgist.js](https://nostalgist.js.org/) (RetroArch compilé en WebAssembly).
Aucun serveur de jeu, aucune installation : tout tourne dans le navigateur, sur
mobile comme sur ordinateur.

---

## ✨ Fonctionnalités

- **22 consoles** émulées via les cores RetroArch (voir liste ci-dessous)
- **Manette physique** (Xbox / PlayStation / générique) prise en charge via la
  Web Gamepad API, avec mapping automatique et raccourcis (save, load, pause, rewind).
  Fonctionne **aussi sur téléphone** (manette Xbox en Bluetooth ou en USB-OTG) :
  détection robuste par scan continu, sans dépendre de l'événement de connexion
- **Manette tactile** intégrée (D-pad, A/B/X/Y, L/R, Start/Select) pour le mobile,
  avec **stick analogique** optionnel (pilote le vrai stick gauche sur N64 / PS1),
  **personnalisable** (taille, opacité, mode gaucher)
- **Touches clavier remappables** : réassignez chaque bouton à la touche de votre choix
- **Gestion des BIOS** : importez les fichiers système requis par certaines consoles
  (PS1, Sega CD, Neo Geo…) ; ils sont stockés et injectés automatiquement au lancement
- **Sauvegardes complètes et persistantes :**
  - **SRAM automatique** — les sauvegardes faites *dans* le jeu (Pokémon, Zelda…)
    sont conservées et rechargées automatiquement (stockées en IndexedDB)
  - **Save states** — 3 slots manuels + 1 slot auto, avec miniatures et horodatage
  - **Auto-save** optionnel (état toutes les 60 s) avec reprise automatique au lancement
- **Bibliothèque de ROMs persistante** : les fichiers sont stockés en
  **IndexedDB**, donc conservés d'une session à l'autre (recherche, filtres par
  console, favoris)
- **Catalogue Homebrew** (jeux libres et légaux) téléchargeables directement,
  via [Homebrew Hub](https://hh.gbdev.io/) avec liste de repli intégrée
- **Jaquettes automatiques** : boxart depuis **libretro-thumbnails** (sans clé),
  puis RAWG.io, TheGamesDB et Wikipédia en complément
- **Choix du core par jeu** : pour les consoles proposant plusieurs émulateurs,
  sélectionnez celui à utiliser (compatibilité ou vitesse) via ⚙️ sur chaque jeu
- **Avance rapide** (bouton ⏩ ou touche `F`) et **rewind** continu (retour dans le temps)
- **Filtres vidéo** : shaders CRT / LCD (CRT rapide, CRT, CRT Pi, LCD), chargés depuis
  libretro/glsl-shaders
- **Options d'affichage** : pixel-perfect (integer scale), lissage bilinéaire,
  compteur FPS
- **Application installable (PWA)** : ajout à l'écran d'accueil, lancement plein
  écran et **fonctionnement hors-ligne** (le shell et les cores déjà joués sont mis en cache)
- **Export / import** : sauvegardez toute votre installation (bibliothèque, ROMs,
  sauvegardes, réglages, touches, BIOS) dans un `.zip` pour la transférer sur un autre appareil
- Persistance locale : ROMs et sauvegardes en **IndexedDB**, préférences en `localStorage`

## 🕹️ Consoles supportées

**22 systèmes jouables** dans le navigateur (cores RetroArch compilés en
WebAssembly + DOSBox via js-dos) :

NES · SNES · Game Boy · Game Boy Color · Game Boy Advance · Mega Drive ·
Master System · Game Gear · PlayStation 1 · PC Engine · Neo Geo · Neo Geo CD ·
Arcade (CPS/FBA) · Sega CD · Atari Lynx · Neo Geo Pocket · Virtual Boy ·
MSX/MSX2 · ColecoVision · Commodore 64 · WonderSwan · **PC / MS-DOS**

### 💾 Jeux PC / DOS (js-dos)

La console **PC / DOS** n'utilise pas RetroArch mais [js-dos](https://js-dos.com)
(DOSBox compilé en WebAssembly, chargé à la demande depuis son CDN). Pour jouer :

- Préparez un **bundle `.jsdos`** de votre jeu (depuis vos fichiers DOS, via le
  Studio sur [v8.js-dos.com](https://v8.js-dos.com)), puis chargez-le comme une ROM.
- Ou testez immédiatement avec le bouton **« 💾 Démo DOS »** de l'accueil (lance
  *Digger*, un jeu libre, directement depuis le CDN js-dos).
- js-dos fournit ses propres contrôles tactiles et un clavier virtuel, pratiques
  sur mobile pour les jeux qui exigent le clavier.

Plusieurs systèmes nécessitent un **BIOS** (badge 🔑 dans l'app) : PS1
(conseillé), Sega CD, Neo Geo, Neo Geo CD, ColecoVision (requis), Atari Lynx
(conseillé). Importez-les dans Réglages → BIOS.

> **Non disponibles en navigateur** : Nintendo 64, Nintendo DS, Atari 2600 et
> Atari 7800. Leurs cores (mupen64plus_next, desmume, stella, prosystem) ne sont
> pas compilés en WebAssembly dans la build standard de RetroArch ; ils restent
> listés dans l'app, signalés « indispo », avec un message explicatif au lancement.

---

## 📁 Arborescence

```
retrovault/
├── index.html        # Structure HTML
├── css/
│   └── styles.css    # Tous les styles
├── js/
│   ├── db.js         # Persistance IndexedDB (ROMs, sauvegardes, BIOS)
│   └── app.js        # Toute la logique (chargé en script classique)
├── sw.js             # Service worker : hors-ligne + injection COOP/COEP
├── manifest.webmanifest  # Manifeste PWA
├── icons/            # Icônes de l'app (192, 512, maskable, apple, favicon)
├── assets/           # (vos captures d'écran, etc.)
├── serve.py          # Serveur de dev local avec en-têtes COOP/COEP
├── _headers          # En-têtes pour Netlify / Cloudflare Pages
├── .nojekyll         # Désactive Jekyll sur GitHub Pages
├── .gitignore
├── LICENSE
└── README.md
```

> ℹ️ Le JavaScript est volontairement regroupé dans un seul fichier `app.js`
> chargé comme **script classique** (pas un module ES) : les gestionnaires
> `onclick` du HTML appellent des fonctions globales. Si vous le passez en
> `type="module"`, ces gestionnaires cesseront de fonctionner.

---

## 🚀 Lancer en local

⚠️ **Ne pas ouvrir `index.html` directement** (`file://`) : l'émulateur a besoin
de `SharedArrayBuffer`, donc d'une isolation cross-origin (en-têtes COOP/COEP)
servie par un vrai serveur HTTP.

**Option recommandée — serveur fourni** (envoie les bons en-têtes) :

```bash
python3 serve.py
# puis ouvrez http://localhost:8000
```

**VS Code** : extension *Live Server* (suffit pour tester l'interface ; selon la
config, SharedArrayBuffer peut ne pas être activé sans les en-têtes COOP/COEP).

À noter : un simple `python3 -m http.server` **ne suffit pas** car il n'envoie
pas les en-têtes COOP/COEP — d'où le `serve.py` fourni.

---

## 🌐 Déploiement

| Plateforme              | Fonctionne ?                | Détails |
|-------------------------|-----------------------------|---------|
| **GitHub Pages**        | ✅ Direct                   | Le **service worker intégré** injecte COOP/COEP — `SharedArrayBuffer` fonctionne sans configuration. Au premier chargement, la page se recharge une fois pour activer l'isolation. |
| **Netlify**             | ✅ Direct                   | Le fichier `_headers` applique COOP/COEP automatiquement |
| **Cloudflare Pages**    | ✅ Direct                   | Idem, via `_headers` |
| **Vercel**              | ✅                          | `_headers` ou en-têtes dans `vercel.json` ; le service worker prend le relais sinon |

L'isolation cross-origin (requise par `SharedArrayBuffer`) est assurée de deux
façons : par les en-têtes serveur (`_headers` / `serve.py`) quand c'est possible,
et **sinon par le service worker** (`sw.js`), qui les injecte lui-même — d'où le
fonctionnement direct sur GitHub Pages. On utilise `COEP: credentialless` afin de
garder l'isolation tout en laissant se charger les jaquettes cross-origin.

---

## 🛠️ Pile technique

- [Nostalgist.js](https://nostalgist.js.org/) `0.12.0` — wrapper RetroArch WASM
- HTML / CSS / JavaScript vanilla — **aucune dépendance de build**
- APIs navigateur : Web Gamepad API, `localStorage`, `fetch`, `ResizeObserver`

---

## ⚖️ Mention légale

RetroVault est conçu pour les **jeux homebrew** (créés et distribués librement par
des développeurs indépendants) et les ROMs que vous possédez légalement.
**Ne piratez pas de jeux commerciaux.** Soutenez les créateurs.

## 📄 Licence

[MIT](LICENSE) — pensez à mettre votre nom dans le fichier `LICENSE`.
